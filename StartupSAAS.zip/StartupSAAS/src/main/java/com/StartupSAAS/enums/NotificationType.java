package com.StartupSAAS.enums;

public enum NotificationType {
  REQUEST_SUBMITTED,
  REQUEST_ASSIGNED,
  REQUEST_UPDATED,
  COMPLETED,
  PAYMENT_DUE,
  PAYMENT_RECEIVED,
  SLA_WARNING,
  WELCOME,
  GENERAL
}

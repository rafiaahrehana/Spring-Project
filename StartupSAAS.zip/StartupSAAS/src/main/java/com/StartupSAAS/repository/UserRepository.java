package com.StartupSAAS.repository;

import com.StartupSAAS.entity.User;
import com.StartupSAAS.enums.Role;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    List<User> findByRole(Role role);

    boolean existsByEmailAndIdNot(String email, Long id);
}
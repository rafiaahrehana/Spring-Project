package com.startuphub.auth;

import com.startuphub.dto.request.*;
import com.startuphub.dto.response.*;
import com.startuphub.entity.*;
import com.startuphub.enums.NotificationType;
import com.startuphub.enums.Role;
import com.startuphub.enums.SubscriptionPlan;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.location.entity.Address;
import com.startuphub.location.entity.PostOffice;
import com.startuphub.location.repository.PostOfficeRepository;
import com.startuphub.mapper.CompanyMapper;
import com.startuphub.repository.*;
import com.startuphub.security.JwtService;
import com.startuphub.service.EmailService;
import com.startuphub.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final WalletRepository walletRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PostOfficeRepository postOfficeRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final EmailService emailService;
    private final NotificationService notificationService;

    @Value("${app.trial-days:14}")
    private int trialDays;

    @Value("${jwt.refresh-expiration-ms}")
    private long refreshExpirationMs;

    @Override
    @Transactional
    public CompanyResponse registerCompany(RegisterCompanyRequest request) {
        if (companyRepository.existsBySubdomain(request.getSubdomain()))
            throw new BadRequestException("Subdomain already taken");
        if (userRepository.existsByEmail(request.getEmail()))
            throw new BadRequestException("Email already registered");

        User owner = new User();
        owner.setFirstName(request.getFirstName());
        owner.setLastName(request.getLastName());
        owner.setEmail(request.getEmail());
        owner.setPhone(request.getPhone());
        owner.setPassword(passwordEncoder.encode(request.getPassword()));
        owner.setRole(Role.COMPANY_OWNER);
        owner.setActive(true);
        userRepository.save(owner);

        Company company = new Company();
        company.setCompanyName(request.getCompanyName());
        company.setSubdomain(request.getSubdomain());
        company.setCompanyPhone(request.getCompanyPhone());
        company.setWebsite(request.getWebsite());
        company.setUser(owner);
        company.setSubscriptionPlan(SubscriptionPlan.FREE);
        company.setActive(true);
        company.setEmailVerified(false);
        company.setSubscriptionStart(LocalDate.now());
        company.setSubscriptionEnd(LocalDate.now().plusDays(trialDays));
        companyRepository.save(company);

        Wallet wallet = new Wallet();
        wallet.setBalance(0.0);
        wallet.setCompany(company);
        walletRepository.save(wallet);

        String verifyToken = UUID.randomUUID().toString();
        emailService.sendVerificationEmail(owner.getEmail(), owner.getFirstName(), verifyToken);

        notificationService.send(owner,
            "Welcome to StartupHub!",
            "Your company workspace is ready. Verify your email to unlock all features.",
            NotificationType.WELCOME, company);

        return CompanyMapper.toResponse(company);
    }

    @Override
    public LoginResponse login(LoginRequest request) {
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        String accessToken = jwtService.generateAccessToken(user.getEmail(),
            Map.of("role", user.getRole().name()));

        RefreshToken refreshToken = RefreshToken.builder()
            .token(UUID.randomUUID().toString())
            .user(user)
            .expiresAt(Instant.now().plusMillis(refreshExpirationMs))
            .build();
        refreshTokenRepository.save(refreshToken);

        return new LoginResponse(user.getId(), user.getEmail(),
            user.getRole().name(), accessToken, refreshToken.getToken());
    }

    @Override
    @Transactional
    public TokenResponse refreshToken(RefreshTokenRequest request) {
        RefreshToken stored = refreshTokenRepository.findByToken(request.getRefreshToken())
            .orElseThrow(() -> new BadRequestException("Invalid refresh token"));

        if (stored.isRevoked() || stored.getExpiresAt().isBefore(Instant.now()))
            throw new BadRequestException("Refresh token expired or revoked");

        User user = stored.getUser();
        String newAccess = jwtService.generateAccessToken(user.getEmail(),
            Map.of("role", user.getRole().name()));

        stored.setRevoked(true);
        RefreshToken newRefresh = RefreshToken.builder()
            .token(UUID.randomUUID().toString())
            .user(user)
            .expiresAt(Instant.now().plusMillis(refreshExpirationMs))
            .build();
        refreshTokenRepository.save(newRefresh);

        return new TokenResponse(newAccess, newRefresh.getToken());
    }

    @Override
    @Transactional
    public void logout(RefreshTokenRequest request) {
        refreshTokenRepository.findByToken(request.getRefreshToken())
            .ifPresent(t -> t.setRevoked(true));
    }

    @Override
    public void forgotPassword(ForgotPasswordRequest request) {
        userRepository.findByEmail(request.getEmail()).ifPresent(user -> {
            String token = UUID.randomUUID().toString();
            emailService.sendPasswordResetEmail(user.getEmail(), user.getFirstName(), token);
        });
    }

    @Override
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        // Token validation would normally check a persisted token table
        // Simplified: client passes token from email link
        throw new BadRequestException("Token-based reset requires a PasswordResetToken table. See documentation.");
    }

    @Override
    @Transactional
    public void verifyEmail(String token) {
        // Token validation would normally check a persisted token table
        // Simplified: hook up to an EmailVerification entity when implementing
        throw new BadRequestException("Email verification requires an EmailVerification table. See documentation.");
    }
}

package com.startuphub.auth;

import com.startuphub.dto.request.*;
import com.startuphub.dto.response.*;

public interface AuthService {
    CompanyResponse registerCompany(RegisterCompanyRequest request);
    LoginResponse login(LoginRequest request);
    TokenResponse refreshToken(RefreshTokenRequest request);
    void logout(RefreshTokenRequest request);
    void forgotPassword(ForgotPasswordRequest request);
    void resetPassword(ResetPasswordRequest request);
    void verifyEmail(String token);
}

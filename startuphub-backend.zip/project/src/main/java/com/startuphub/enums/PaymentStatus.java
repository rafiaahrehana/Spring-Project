package com.startuphub.enums;
public enum PaymentStatus { PENDING, COMPLETED, FAILED, REFUNDED }

package com.startuphub.enums;
public enum DiscountType { PERCENT, FIXED }

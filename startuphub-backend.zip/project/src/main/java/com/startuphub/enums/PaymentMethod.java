package com.startuphub.enums;
public enum PaymentMethod { BKASH, NAGAD, ROCKET, CARD, BANK_TRANSFER, CASH, WALLET }

package com.startuphub.enums;
public enum Priority { LOW, NORMAL, HIGH, URGENT }

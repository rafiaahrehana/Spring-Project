package com.startuphub.enums;
public enum AuditEntityType { USER, EMPLOYEE, COMPANY, CLIENT, SERVICE_REQUEST, TASK, INVOICE, PAYMENT, HUB_SERVICE, DOCUMENT }

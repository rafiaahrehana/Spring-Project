package com.startuphub.enums;
public enum WalletTransactionType { CREDIT, DEBIT }

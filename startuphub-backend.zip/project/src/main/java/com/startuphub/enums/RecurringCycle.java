package com.startuphub.enums;
public enum RecurringCycle { MONTHLY, YEARLY }

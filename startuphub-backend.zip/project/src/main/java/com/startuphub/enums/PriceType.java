package com.startuphub.enums;
public enum PriceType { FIXED, WEEKLY, MONTHLY, CUSTOM }

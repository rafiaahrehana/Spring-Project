package com.startuphub.enums;
public enum SubscriptionPlan { FREE, STARTER, PRO, ENTERPRISE }

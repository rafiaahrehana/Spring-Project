package com.startuphub.enums;
public enum RequestStatus { PENDING, ASSIGNED, IN_PROGRESS, REVIEW, COMPLETED, REJECTED, CANCELLED }

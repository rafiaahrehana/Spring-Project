package com.startuphub.dto.request;

import com.startuphub.enums.Designation;
import com.startuphub.enums.Gender;
import com.startuphub.enums.Role;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class EmployeeRequest {
    @NotBlank private String firstName;
    @NotBlank private String lastName;
    @Email @NotBlank private String email;
    @NotBlank @Size(min = 8) private String password;
    private String phone;

    @NotNull @Past private LocalDate dob;
    private Gender gender;
    private Designation designation;
    private Role role;
    private LocalDate hireDate;

    private Long postOfficeId;
    private String houseNo;
    private String road;
}

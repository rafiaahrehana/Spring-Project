package com.startuphub.dto.response;

import com.startuphub.enums.InvoiceStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record InvoiceResponse(
    Long id,
    String invoiceNumber,
    InvoiceStatus status,
    Double subtotal,
    Double discountAmount,
    Double taxAmount,
    Double totalAmount,
    Double paidAmount,
    LocalDate issueDate,
    LocalDate dueDate,
    String notes,
    Long serviceRequestId,
    Long clientId,
    String clientName,
    Long companyId,
    LocalDateTime createdAt
) {}

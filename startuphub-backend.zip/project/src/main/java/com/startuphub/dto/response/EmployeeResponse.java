package com.startuphub.dto.response;

import com.startuphub.enums.Designation;
import com.startuphub.enums.Gender;
import com.startuphub.enums.Role;
import com.startuphub.location.response.AddressResponse;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record EmployeeResponse(
    Long id,
    String firstName,
    String lastName,
    String email,
    String phone,
    String image,
    Role role,
    boolean active,
    Designation designation,
    Gender gender,
    LocalDate dob,
    LocalDate hireDate,
    Long companyId,
    String companyName,
    AddressResponse address,
    LocalDateTime createdAt
) {}

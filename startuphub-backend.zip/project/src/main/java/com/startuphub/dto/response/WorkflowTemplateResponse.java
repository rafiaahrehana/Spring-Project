package com.startuphub.dto.response;

import java.time.LocalDateTime;
import java.util.List;

public record WorkflowTemplateResponse(
    Long id,
    String name,
    String description,
    boolean active,
    List<StageResponse> stages,
    LocalDateTime createdAt
) {
    public record StageResponse(
        Long id,
        String name,
        String description,
        Integer stageOrder,
        Integer estimatedDays
    ) {}
}

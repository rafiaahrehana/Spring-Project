package com.startuphub.dto.response;

import com.startuphub.enums.NotificationType;

import java.time.LocalDateTime;

public record NotificationResponse(
    Long id,
    String title,
    String message,
    NotificationType type,
    boolean isRead,
    LocalDateTime readAt,
    Long serviceRequestId,
    LocalDateTime createdAt
) {}

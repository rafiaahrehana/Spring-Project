package com.startuphub.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AssignRequestRequest {
    @NotNull private Long employeeId;
}

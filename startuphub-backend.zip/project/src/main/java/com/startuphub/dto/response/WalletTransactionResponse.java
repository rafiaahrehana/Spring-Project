package com.startuphub.dto.response;

import com.startuphub.enums.WalletTransactionType;

import java.time.LocalDateTime;

public record WalletTransactionResponse(
    Long id,
    Double amount,
    WalletTransactionType type,
    Double balanceAfter,
    String reference,
    LocalDateTime transactedAt
) {}

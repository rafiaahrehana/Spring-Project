package com.startuphub.dto.request;

import com.startuphub.enums.PriceType;
import com.startuphub.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class HubServiceRequest {
    @NotBlank private String name;
    private String description;
    private String iconUrl;
    @NotNull @Positive private Double price;
    private PriceType priceType = PriceType.FIXED;
    private Integer estimatedDays;
    private Priority defaultPriority = Priority.NORMAL;
    private Long workflowTemplateId;
}

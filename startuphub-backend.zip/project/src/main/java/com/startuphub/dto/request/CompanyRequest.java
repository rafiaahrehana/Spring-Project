package com.startuphub.dto.request;

import com.startuphub.enums.SubscriptionPlan;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CompanyRequest {
    @NotBlank private String companyName;
    private String companyEmail;
    private String companyPhone;
    @NotBlank private String subdomain;
    private String website;

    @NotBlank private String firstName;
    @NotBlank private String lastName;
    @NotBlank private String email;
    @NotBlank private String password;
    private String phone;

    private SubscriptionPlan subscriptionPlan;
    private LocalDate subscriptionStart;
    private LocalDate subscriptionEnd;

    private Long postOfficeId;
    private String houseNo;
    private String road;
}

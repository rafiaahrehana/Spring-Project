package com.startuphub.dto.response;

public record LoginResponse(
    Long userId,
    String email,
    String role,
    String accessToken,
    String refreshToken
) {}

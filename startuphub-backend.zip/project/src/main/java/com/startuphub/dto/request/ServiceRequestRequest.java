package com.startuphub.dto.request;

import com.startuphub.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ServiceRequestRequest {
    @NotBlank private String title;
    private String description;
    @NotNull private Long hubServiceId;
    private Priority priority = Priority.NORMAL;
    private LocalDate deadline;
    private Double agreedPrice;
}

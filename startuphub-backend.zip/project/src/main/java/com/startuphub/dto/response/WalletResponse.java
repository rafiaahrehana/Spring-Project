package com.startuphub.dto.response;

public record WalletResponse(
    Long id,
    Double balance,
    Long companyId,
    String companyName
) {}

package com.startuphub.dto.response;

import com.startuphub.location.response.AddressResponse;

import java.time.LocalDateTime;

public record ClientResponse(
    Long id,
    String firstName,
    String lastName,
    String email,
    String phone,
    String image,
    String billingAddress,
    Long companyId,
    String companyName,
    AddressResponse address,
    LocalDateTime createdAt
) {}

package com.startuphub.dto.request;

import com.startuphub.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
public class TaskRequest {
    @NotBlank private String title;
    private String description;
    private Priority priority = Priority.NORMAL;
    private LocalDate dueDate;
    private Long assignedEmployeeId;
    private String notes;
}

package com.startuphub.dto.response;

import com.startuphub.enums.Priority;
import com.startuphub.enums.RequestStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record ServiceRequestResponse(
    Long id,
    String title,
    String description,
    RequestStatus status,
    Priority priority,
    LocalDate deadline,
    LocalDateTime assignedAt,
    LocalDateTime completedAt,
    Double agreedPrice,
    Integer currentStage,
    Integer slaHours,
    Long hubServiceId,
    String serviceName,
    Long clientId,
    String clientName,
    Long companyId,
    Long assignedEmployeeId,
    String assignedEmployeeName,
    LocalDateTime createdAt
) {}

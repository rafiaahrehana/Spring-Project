package com.startuphub.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class WorkflowTemplateRequest {
    @NotBlank private String name;
    private String description;
    @NotEmpty private List<StageRequest> stages;

    @Data
    public static class StageRequest {
        @NotBlank private String name;
        private String description;
        private Integer estimatedDays;
    }
}

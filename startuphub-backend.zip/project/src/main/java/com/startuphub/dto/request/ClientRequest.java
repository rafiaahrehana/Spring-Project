package com.startuphub.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ClientRequest {
    @NotBlank private String firstName;
    @NotBlank private String lastName;
    @Email @NotBlank private String email;
    @NotBlank @Size(min = 8) private String password;
    private String phone;
    private String billingAddress;

    private Long postOfficeId;
    private String houseNo;
    private String road;
}

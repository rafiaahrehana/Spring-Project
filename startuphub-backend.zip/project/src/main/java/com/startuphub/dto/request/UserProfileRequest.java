package com.startuphub.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UserProfileRequest {
    @NotBlank private String firstName;
    @NotBlank private String lastName;
    private String phone;

    private Long postOfficeId;
    private String houseNo;
    private String road;
}

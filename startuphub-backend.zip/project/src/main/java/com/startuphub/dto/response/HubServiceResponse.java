package com.startuphub.dto.response;

import com.startuphub.enums.PriceType;
import com.startuphub.enums.Priority;

public record HubServiceResponse(
    Long id,
    String name,
    String description,
    String iconUrl,
    Double price,
    PriceType priceType,
    Integer estimatedDays,
    Priority defaultPriority,
    boolean active,
    Long companyId,
    Long workflowTemplateId,
    String workflowTemplateName
) {}

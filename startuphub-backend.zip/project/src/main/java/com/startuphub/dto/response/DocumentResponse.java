package com.startuphub.dto.response;

import java.time.LocalDateTime;

public record DocumentResponse(
    Long id,
    String fileName,
    String fileUrl,
    String fileType,
    Long fileSizeBytes,
    String label,
    String notes,
    Long serviceRequestId,
    Long uploadedById,
    LocalDateTime createdAt
) {}

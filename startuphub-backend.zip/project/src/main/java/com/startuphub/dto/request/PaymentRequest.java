package com.startuphub.dto.request;

import com.startuphub.enums.PaymentMethod;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class PaymentRequest {
    @NotNull private Long invoiceId;
    @NotNull @Positive private Double amount;
    @NotNull private PaymentMethod paymentMethod;
    private String transactionId;
    private String notes;
}

package com.startuphub.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.time.LocalDate;

@Data
public class InvoiceRequest {
    @NotNull private Long serviceRequestId;
    @NotNull @Positive private Double subtotal;
    private Double discountAmount = 0.0;
    private Double taxAmount = 0.0;
    private LocalDate dueDate;
    private String notes;
    private String promoCode;
}

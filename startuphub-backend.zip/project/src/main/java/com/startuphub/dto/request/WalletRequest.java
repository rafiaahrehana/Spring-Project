package com.startuphub.dto.request;

import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class WalletRequest {
    @Positive(message = "Amount must be positive")
    private Double amount;
    private String reference;
}

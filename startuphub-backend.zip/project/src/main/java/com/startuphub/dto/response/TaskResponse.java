package com.startuphub.dto.response;

import com.startuphub.enums.Priority;
import com.startuphub.enums.TaskStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record TaskResponse(
    Long id,
    String title,
    String description,
    TaskStatus status,
    Priority priority,
    LocalDate dueDate,
    LocalDateTime completedAt,
    String notes,
    Long serviceRequestId,
    Long assignedEmployeeId,
    String assignedEmployeeName,
    Long createdById,
    LocalDateTime createdAt
) {}

package com.startuphub.dto.response;

import com.startuphub.enums.SubscriptionPlan;
import com.startuphub.location.response.AddressResponse;

import java.time.LocalDate;

public record CompanyResponse(
    Long id,
    String companyName,
    String companyEmail,
    String companyPhone,
    String subdomain,
    String logo,
    String website,
    SubscriptionPlan subscriptionPlan,
    boolean active,
    boolean emailVerified,
    LocalDate subscriptionStart,
    LocalDate subscriptionEnd,
    Long ownerId,
    String ownerName,
    AddressResponse address
) {}

package com.startuphub.dto.response;

import com.startuphub.enums.PaymentMethod;
import com.startuphub.enums.PaymentStatus;

import java.time.LocalDateTime;

public record PaymentResponse(
    Long id,
    Double amount,
    PaymentMethod paymentMethod,
    PaymentStatus status,
    String transactionId,
    LocalDateTime paidAt,
    Long invoiceId,
    String invoiceNumber,
    Long clientId,
    LocalDateTime createdAt
) {}

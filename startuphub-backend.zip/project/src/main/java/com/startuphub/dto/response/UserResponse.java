package com.startuphub.dto.response;

import com.startuphub.enums.Role;
import com.startuphub.location.response.AddressResponse;

import java.time.LocalDateTime;

public record UserResponse(
    Long id,
    String firstName,
    String lastName,
    String email,
    String phone,
    Role role,
    boolean active,
    String image,
    AddressResponse address,
    LocalDateTime createdAt
) {}

package com.startuphub.entity;

import com.startuphub.enums.SubscriptionPlan;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "companies")
@Getter @Setter @NoArgsConstructor
public class Company extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String companyName;

    @Column(unique = true)
    private String companyEmail;

    @Column(unique = true)
    private String companyPhone;

    private String logo;
    private String website;

    @Column(nullable = false, unique = true)
    private String subdomain;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SubscriptionPlan subscriptionPlan = SubscriptionPlan.FREE;

    private boolean active = false;
    private boolean emailVerified = false;

    private LocalDate subscriptionStart;
    private LocalDate subscriptionEnd;
}

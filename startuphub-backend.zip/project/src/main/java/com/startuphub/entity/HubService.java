package com.startuphub.entity;

import com.startuphub.enums.PriceType;
import com.startuphub.enums.Priority;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "hub_services")
@Getter @Setter @NoArgsConstructor
public class HubService extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String iconUrl;
    private Double price;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PriceType priceType = PriceType.FIXED;

    private Integer estimatedDays;

    @Enumerated(EnumType.STRING)
    private Priority defaultPriority = Priority.NORMAL;

    private boolean active = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workflow_template_id")
    private WorkflowTemplate workflowTemplate;
}

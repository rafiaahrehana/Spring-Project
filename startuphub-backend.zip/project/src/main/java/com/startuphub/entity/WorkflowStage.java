package com.startuphub.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "workflow_stages")
@Getter @Setter @NoArgsConstructor
public class WorkflowStage extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private Integer stageOrder;

    private Integer estimatedDays;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workflow_template_id", nullable = false)
    private WorkflowTemplate workflowTemplate;
}

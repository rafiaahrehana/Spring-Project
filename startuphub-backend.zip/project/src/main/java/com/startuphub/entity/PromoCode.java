package com.startuphub.entity;

import com.startuphub.enums.DiscountType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "promo_codes")
@Getter @Setter @NoArgsConstructor
public class PromoCode extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String code;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DiscountType discountType = DiscountType.PERCENT;

    @Column(nullable = false)
    private Double discountValue;

    private Double minOrderAmount;
    private Integer maxUses;
    private Integer usedCount = 0;

    private LocalDate validFrom;
    private LocalDate validUntil;

    private boolean active = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;
}

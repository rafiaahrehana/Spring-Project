package com.startuphub.filter;

import com.startuphub.entity.Company;
import com.startuphub.entity.User;
import com.startuphub.enums.Role;
import com.startuphub.repository.CompanyRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class CompanyActiveFilter extends OncePerRequestFilter {

    private final CompanyRepository companyRepository;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain)
            throws ServletException, IOException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null && auth.isAuthenticated() && auth.getPrincipal() instanceof User user) {
            if (user.getRole() != Role.SUPER_ADMIN) {
                Company company = companyRepository.findByUserId(user.getId()).orElse(null);
                if (company == null) {
                    // Employee or client — find via their company
                    company = companyRepository.findByEmployeeUserId(user.getId())
                        .or(() -> companyRepository.findByClientUserId(user.getId()))
                        .orElse(null);
                }
                if (company != null && !company.isActive()) {
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    response.setContentType("application/json");
                    response.getWriter().write("{\"message\": \"Company subscription expired or inactive\"}");
                    response.getWriter().flush();
                    return;
                }
            }
        }

        chain.doFilter(request, response);
    }
}

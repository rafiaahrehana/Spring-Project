package com.startuphub.scheduler;

import com.startuphub.entity.Company;
import com.startuphub.entity.Invoice;
import com.startuphub.enums.InvoiceStatus;
import com.startuphub.repository.CompanyRepository;
import com.startuphub.repository.InvoiceRepository;
import com.startuphub.service.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class SubscriptionScheduler {

    private final CompanyRepository companyRepository;
    private final InvoiceRepository invoiceRepository;
    private final EmailService emailService;

    @Scheduled(cron = "0 0 0 * * *")
    @Transactional
    public void deactivateExpiredSubscriptions() {
        List<Company> expired = companyRepository.findByActiveAndSubscriptionEndBefore(true, LocalDate.now());
        expired.forEach(c -> {
            c.setActive(false);
            log.info("Deactivated company: {} (subscription ended {})", c.getCompanyName(), c.getSubscriptionEnd());
        });
    }

    @Scheduled(cron = "0 0 8 * * *")
    public void sendTrialExpiringWarnings() {
        LocalDate today = LocalDate.now();
        LocalDate in3Days = today.plusDays(3);
        companyRepository.findByActiveAndSubscriptionEndBefore(true, in3Days.plusDays(1))
            .stream()
            .filter(c -> !c.getSubscriptionEnd().isBefore(in3Days))
            .forEach(c -> {
                if (c.getUser() != null) {
                    long daysLeft = ChronoUnit.DAYS.between(today, c.getSubscriptionEnd());
                    emailService.sendTrialExpiringEmail(
                        c.getUser().getEmail(),
                        c.getUser().getFirstName(),
                        c.getCompanyName(),
                        (int) daysLeft
                    );
                    log.info("Sent trial-expiring email to: {}", c.getUser().getEmail());
                }
            });
    }

    @Scheduled(cron = "0 0 1 * * *")
    @Transactional
    public void markOverdueInvoices() {
        List<Invoice> overdue = invoiceRepository.findByStatusAndDueDateBefore(InvoiceStatus.SENT, LocalDate.now());
        overdue.forEach(inv -> {
            inv.setStatus(InvoiceStatus.OVERDUE);
            log.info("Marked invoice {} as OVERDUE", inv.getInvoiceNumber());
        });
    }
}

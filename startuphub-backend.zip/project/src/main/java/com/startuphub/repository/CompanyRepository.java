package com.startuphub.repository;

import com.startuphub.entity.Company;
import com.startuphub.enums.SubscriptionPlan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface CompanyRepository extends JpaRepository<Company, Long> {
    Optional<Company> findByUserId(Long userId);
    boolean existsBySubdomain(String subdomain);
    boolean existsByCompanyEmail(String email);
    Page<Company> findByCompanyNameContainingIgnoreCase(String name, Pageable pageable);
    Page<Company> findBySubscriptionPlan(SubscriptionPlan plan, Pageable pageable);
    List<Company> findByActiveAndSubscriptionEndBefore(boolean active, LocalDate date);

    @Query("SELECT e.company FROM Employee e WHERE e.user.id = :userId")
    Optional<Company> findByEmployeeUserId(Long userId);

    @Query("SELECT c.company FROM Client c WHERE c.user.id = :userId")
    Optional<Company> findByClientUserId(Long userId);
}

package com.startuphub.repository;

import com.startuphub.entity.AuditLog;
import com.startuphub.enums.AuditEntityType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    Page<AuditLog> findByCompanyId(Long companyId, Pageable pageable);
    Page<AuditLog> findByEntityTypeAndEntityId(AuditEntityType type, Long entityId, Pageable pageable);
}

package com.startuphub.repository;

import com.startuphub.entity.Client;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ClientRepository extends JpaRepository<Client, Long> {
    Page<Client> findByCompanyId(Long companyId, Pageable pageable);
    boolean existsByCompanyId(Long companyId);
    Optional<Client> findByUserId(Long userId);
}

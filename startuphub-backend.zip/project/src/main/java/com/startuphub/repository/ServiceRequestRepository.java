package com.startuphub.repository;

import com.startuphub.entity.ServiceRequest;
import com.startuphub.enums.RequestStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, Long> {
    Page<ServiceRequest> findByCompanyId(Long companyId, Pageable pageable);
    Page<ServiceRequest> findByClientId(Long clientId, Pageable pageable);
    Page<ServiceRequest> findByAssignedEmployeeId(Long employeeId, Pageable pageable);
    Page<ServiceRequest> findByCompanyIdAndStatus(Long companyId, RequestStatus status, Pageable pageable);
}

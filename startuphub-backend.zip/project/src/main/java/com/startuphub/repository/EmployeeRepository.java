package com.startuphub.repository;

import com.startuphub.entity.Employee;
import com.startuphub.enums.Designation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Page<Employee> findByCompanyId(Long companyId, Pageable pageable);
    List<Employee> findByCompanyIdAndDesignation(Long companyId, Designation designation);
    boolean existsByCompanyId(Long companyId);
    Optional<Employee> findByUserId(Long userId);
}

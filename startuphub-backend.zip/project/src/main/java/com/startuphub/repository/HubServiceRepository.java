package com.startuphub.repository;

import com.startuphub.entity.HubService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HubServiceRepository extends JpaRepository<HubService, Long> {
    Page<HubService> findByCompanyId(Long companyId, Pageable pageable);
    Page<HubService> findByCompanyIdAndActive(Long companyId, boolean active, Pageable pageable);
}

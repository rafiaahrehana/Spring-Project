package com.startuphub.repository;

import com.startuphub.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DocumentRepository extends JpaRepository<Document, Long> {
    List<Document> findByServiceRequestId(Long requestId);
}

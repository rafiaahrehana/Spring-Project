package com.startuphub.repository;

import com.startuphub.entity.Invoice;
import com.startuphub.enums.InvoiceStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    Page<Invoice> findByCompanyId(Long companyId, Pageable pageable);
    Page<Invoice> findByClientId(Long clientId, Pageable pageable);
    Optional<Invoice> findByServiceRequestId(Long requestId);
    List<Invoice> findByStatusAndDueDateBefore(InvoiceStatus status, LocalDate date);
}

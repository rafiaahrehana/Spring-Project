package com.startuphub.repository;

import com.startuphub.entity.Task;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByServiceRequestId(Long requestId);
    Page<Task> findByAssignedEmployeeId(Long employeeId, Pageable pageable);
}

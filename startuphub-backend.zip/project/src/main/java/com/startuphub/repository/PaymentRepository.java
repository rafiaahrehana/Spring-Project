package com.startuphub.repository;

import com.startuphub.entity.Payment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Page<Payment> findByCompanyId(Long companyId, Pageable pageable);
    Page<Payment> findByInvoiceId(Long invoiceId, Pageable pageable);
}

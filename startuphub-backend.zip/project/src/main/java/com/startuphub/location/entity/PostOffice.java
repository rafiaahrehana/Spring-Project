package com.startuphub.location.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "post_offices")
@Getter @Setter @NoArgsConstructor
public class PostOffice {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String postalCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "police_station_id")
    private PoliceStation policeStation;
}

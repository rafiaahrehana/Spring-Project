package com.startuphub.location.response;

public record AddressResponse(
    Long id,
    String houseNo,
    String road,
    String postOffice,
    String postalCode,
    String policeStation,
    String district,
    String division,
    String country
) {}

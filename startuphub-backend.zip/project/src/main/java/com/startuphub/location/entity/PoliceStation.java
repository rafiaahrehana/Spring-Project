package com.startuphub.location.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "police_stations")
@Getter @Setter @NoArgsConstructor
public class PoliceStation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "district_id")
    private District district;
}

package com.startuphub.location.repository;

import com.startuphub.location.entity.PoliceStation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PoliceStationRepository extends JpaRepository<PoliceStation, Long> {
    List<PoliceStation> findByDistrictId(Long districtId);
}

package com.startuphub.location.repository;

import com.startuphub.location.entity.PostOffice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PostOfficeRepository extends JpaRepository<PostOffice, Long> {
    List<PostOffice> findByPoliceStationId(Long policeStationId);
}

package com.startuphub.location.controller;

import com.startuphub.location.entity.*;
import com.startuphub.location.repository.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/locations")
@RequiredArgsConstructor
@Tag(name = "Locations", description = "Country, division, district, police station, post office data")
public class LocationController {

    private final CountryRepository countryRepository;
    private final DivisionRepository divisionRepository;
    private final DistrictRepository districtRepository;
    private final PoliceStationRepository policeStationRepository;
    private final PostOfficeRepository postOfficeRepository;

    @GetMapping("/countries")
    @Operation(summary = "Get all countries")
    public ResponseEntity<List<Country>> getCountries() {
        return ResponseEntity.ok(countryRepository.findAll());
    }

    @GetMapping("/countries/{countryId}/divisions")
    @Operation(summary = "Get divisions by country")
    public ResponseEntity<List<Division>> getDivisions(@PathVariable Long countryId) {
        return ResponseEntity.ok(divisionRepository.findByCountryId(countryId));
    }

    @GetMapping("/divisions/{divisionId}/districts")
    @Operation(summary = "Get districts by division")
    public ResponseEntity<List<District>> getDistricts(@PathVariable Long divisionId) {
        return ResponseEntity.ok(districtRepository.findByDivisionId(divisionId));
    }

    @GetMapping("/districts/{districtId}/police-stations")
    @Operation(summary = "Get police stations by district")
    public ResponseEntity<List<PoliceStation>> getPoliceStations(@PathVariable Long districtId) {
        return ResponseEntity.ok(policeStationRepository.findByDistrictId(districtId));
    }

    @GetMapping("/police-stations/{policeStationId}/post-offices")
    @Operation(summary = "Get post offices by police station")
    public ResponseEntity<List<PostOffice>> getPostOffices(@PathVariable Long policeStationId) {
        return ResponseEntity.ok(postOfficeRepository.findByPoliceStationId(policeStationId));
    }
}

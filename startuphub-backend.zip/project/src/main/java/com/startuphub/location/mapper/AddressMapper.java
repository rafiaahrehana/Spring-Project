package com.startuphub.location.mapper;

import com.startuphub.location.entity.Address;
import com.startuphub.location.entity.PostOffice;
import com.startuphub.location.entity.PoliceStation;
import com.startuphub.location.entity.District;
import com.startuphub.location.entity.Division;
import com.startuphub.location.entity.Country;
import com.startuphub.location.response.AddressResponse;

public final class AddressMapper {

    private AddressMapper() {}

    public static AddressResponse toResponse(Address address) {
        if (address == null) return null;
        PostOffice po = address.getPostOffice();
        PoliceStation ps = po != null ? po.getPoliceStation() : null;
        District district = ps != null ? ps.getDistrict() : null;
        Division division = district != null ? district.getDivision() : null;
        Country country = division != null ? division.getCountry() : null;

        return new AddressResponse(
            address.getId(),
            address.getHouseNo(),
            address.getRoad(),
            po != null ? po.getName() : null,
            po != null ? po.getPostalCode() : null,
            ps != null ? ps.getName() : null,
            district != null ? district.getName() : null,
            division != null ? division.getName() : null,
            country != null ? country.getName() : null
        );
    }
}

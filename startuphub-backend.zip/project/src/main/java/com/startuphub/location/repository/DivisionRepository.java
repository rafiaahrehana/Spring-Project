package com.startuphub.location.repository;

import com.startuphub.location.entity.Division;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DivisionRepository extends JpaRepository<Division, Long> {
    List<Division> findByCountryId(Long countryId);
}

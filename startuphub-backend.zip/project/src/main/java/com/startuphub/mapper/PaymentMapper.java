package com.startuphub.mapper;

import com.startuphub.dto.response.PaymentResponse;
import com.startuphub.entity.Payment;

public final class PaymentMapper {
    private PaymentMapper() {}

    public static PaymentResponse toResponse(Payment p) {
        return new PaymentResponse(
            p.getId(), p.getAmount(), p.getPaymentMethod(),
            p.getStatus(), p.getTransactionId(), p.getPaidAt(),
            p.getInvoice() != null ? p.getInvoice().getId() : null,
            p.getInvoice() != null ? p.getInvoice().getInvoiceNumber() : null,
            p.getClient() != null ? p.getClient().getId() : null,
            p.getCreatedAt()
        );
    }
}

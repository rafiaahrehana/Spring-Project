package com.startuphub.mapper;

import com.startuphub.dto.response.InvoiceResponse;
import com.startuphub.entity.Invoice;
import com.startuphub.entity.User;

public final class InvoiceMapper {
    private InvoiceMapper() {}

    public static InvoiceResponse toResponse(Invoice inv) {
        User clientUser = inv.getClient() != null ? inv.getClient().getUser() : null;
        return new InvoiceResponse(
            inv.getId(), inv.getInvoiceNumber(), inv.getStatus(),
            inv.getSubtotal(), inv.getDiscountAmount(),
            inv.getTaxAmount(), inv.getTotalAmount(), inv.getPaidAmount(),
            inv.getIssueDate(), inv.getDueDate(), inv.getNotes(),
            inv.getServiceRequest() != null ? inv.getServiceRequest().getId() : null,
            inv.getClient() != null ? inv.getClient().getId() : null,
            clientUser != null ? clientUser.getFirstName() + " " + clientUser.getLastName() : null,
            inv.getCompany() != null ? inv.getCompany().getId() : null,
            inv.getCreatedAt()
        );
    }
}

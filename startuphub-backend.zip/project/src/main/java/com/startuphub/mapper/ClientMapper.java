package com.startuphub.mapper;

import com.startuphub.dto.response.ClientResponse;
import com.startuphub.entity.Client;
import com.startuphub.entity.User;
import com.startuphub.location.mapper.AddressMapper;

public final class ClientMapper {
    private ClientMapper() {}

    public static ClientResponse toResponse(Client c) {
        User u = c.getUser();
        return new ClientResponse(
            c.getId(),
            u != null ? u.getFirstName() : null,
            u != null ? u.getLastName() : null,
            u != null ? u.getEmail() : null,
            u != null ? u.getPhone() : null,
            u != null ? u.getImage() : null,
            c.getBillingAddress(),
            c.getCompany() != null ? c.getCompany().getId() : null,
            c.getCompany() != null ? c.getCompany().getCompanyName() : null,
            u != null ? AddressMapper.toResponse(u.getAddress()) : null,
            c.getCreatedAt()
        );
    }
}

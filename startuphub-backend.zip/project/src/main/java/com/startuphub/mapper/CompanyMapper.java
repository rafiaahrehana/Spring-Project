package com.startuphub.mapper;

import com.startuphub.dto.response.CompanyResponse;
import com.startuphub.entity.Company;
import com.startuphub.location.mapper.AddressMapper;

public final class CompanyMapper {
    private CompanyMapper() {}

    public static CompanyResponse toResponse(Company c) {
        String ownerName = c.getUser() != null
            ? c.getUser().getFirstName() + " " + c.getUser().getLastName()
            : null;
        return new CompanyResponse(
            c.getId(), c.getCompanyName(), c.getCompanyEmail(),
            c.getCompanyPhone(), c.getSubdomain(), c.getLogo(),
            c.getWebsite(), c.getSubscriptionPlan(),
            c.isActive(), c.isEmailVerified(),
            c.getSubscriptionStart(), c.getSubscriptionEnd(),
            c.getUser() != null ? c.getUser().getId() : null,
            ownerName,
            c.getUser() != null ? AddressMapper.toResponse(c.getUser().getAddress()) : null
        );
    }
}

package com.startuphub.mapper;

import com.startuphub.dto.response.WorkflowTemplateResponse;
import com.startuphub.entity.WorkflowTemplate;

import java.util.List;

public final class WorkflowMapper {
    private WorkflowMapper() {}

    public static WorkflowTemplateResponse toResponse(WorkflowTemplate t) {
        List<WorkflowTemplateResponse.StageResponse> stages = t.getStages().stream()
            .map(s -> new WorkflowTemplateResponse.StageResponse(
                s.getId(), s.getName(), s.getDescription(),
                s.getStageOrder(), s.getEstimatedDays()
            )).toList();
        return new WorkflowTemplateResponse(
            t.getId(), t.getName(), t.getDescription(),
            t.isActive(), stages, t.getCreatedAt()
        );
    }
}

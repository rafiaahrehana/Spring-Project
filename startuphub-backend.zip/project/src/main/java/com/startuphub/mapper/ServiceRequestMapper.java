package com.startuphub.mapper;

import com.startuphub.dto.response.ServiceRequestResponse;
import com.startuphub.entity.Employee;
import com.startuphub.entity.ServiceRequest;
import com.startuphub.entity.User;

public final class ServiceRequestMapper {
    private ServiceRequestMapper() {}

    public static ServiceRequestResponse toResponse(ServiceRequest r) {
        Employee emp = r.getAssignedEmployee();
        User empUser = emp != null ? emp.getUser() : null;
        User clientUser = r.getClient() != null ? r.getClient().getUser() : null;

        return new ServiceRequestResponse(
            r.getId(), r.getTitle(), r.getDescription(),
            r.getStatus(), r.getPriority(),
            r.getDeadline(), r.getAssignedAt(), r.getCompletedAt(),
            r.getAgreedPrice(), r.getCurrentStage(), r.getSlaHours(),
            r.getHubService() != null ? r.getHubService().getId() : null,
            r.getHubService() != null ? r.getHubService().getName() : null,
            r.getClient() != null ? r.getClient().getId() : null,
            clientUser != null ? clientUser.getFirstName() + " " + clientUser.getLastName() : null,
            r.getCompany() != null ? r.getCompany().getId() : null,
            emp != null ? emp.getId() : null,
            empUser != null ? empUser.getFirstName() + " " + empUser.getLastName() : null,
            r.getCreatedAt()
        );
    }
}

package com.startuphub.mapper;

import com.startuphub.dto.response.HubServiceResponse;
import com.startuphub.entity.HubService;

public final class HubServiceMapper {
    private HubServiceMapper() {}

    public static HubServiceResponse toResponse(HubService s) {
        return new HubServiceResponse(
            s.getId(), s.getName(), s.getDescription(),
            s.getIconUrl(), s.getPrice(), s.getPriceType(),
            s.getEstimatedDays(), s.getDefaultPriority(), s.isActive(),
            s.getCompany() != null ? s.getCompany().getId() : null,
            s.getWorkflowTemplate() != null ? s.getWorkflowTemplate().getId() : null,
            s.getWorkflowTemplate() != null ? s.getWorkflowTemplate().getName() : null
        );
    }
}

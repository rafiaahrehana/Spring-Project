package com.startuphub.mapper;

import com.startuphub.dto.response.TaskResponse;
import com.startuphub.entity.Employee;
import com.startuphub.entity.Task;
import com.startuphub.entity.User;

public final class TaskMapper {
    private TaskMapper() {}

    public static TaskResponse toResponse(Task t) {
        Employee emp = t.getAssignedEmployee();
        User empUser = emp != null ? emp.getUser() : null;

        return new TaskResponse(
            t.getId(), t.getTitle(), t.getDescription(),
            t.getStatus(), t.getPriority(),
            t.getDueDate(), t.getCompletedAt(), t.getNotes(),
            t.getServiceRequest() != null ? t.getServiceRequest().getId() : null,
            emp != null ? emp.getId() : null,
            empUser != null ? empUser.getFirstName() + " " + empUser.getLastName() : null,
            t.getCreatedBy() != null ? t.getCreatedBy().getId() : null,
            t.getCreatedAt()
        );
    }
}

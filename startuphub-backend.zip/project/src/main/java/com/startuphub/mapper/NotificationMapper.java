package com.startuphub.mapper;

import com.startuphub.dto.response.NotificationResponse;
import com.startuphub.entity.Notification;

public final class NotificationMapper {
    private NotificationMapper() {}

    public static NotificationResponse toResponse(Notification n) {
        return new NotificationResponse(
            n.getId(), n.getTitle(), n.getMessage(),
            n.getType(), n.isRead(), n.getReadAt(),
            n.getServiceRequest() != null ? n.getServiceRequest().getId() : null,
            n.getCreatedAt()
        );
    }
}

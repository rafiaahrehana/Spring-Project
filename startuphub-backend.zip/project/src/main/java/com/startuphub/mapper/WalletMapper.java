package com.startuphub.mapper;

import com.startuphub.dto.response.WalletResponse;
import com.startuphub.dto.response.WalletTransactionResponse;
import com.startuphub.entity.Wallet;
import com.startuphub.entity.WalletTransaction;

public final class WalletMapper {
    private WalletMapper() {}

    public static WalletResponse toResponse(Wallet w) {
        return new WalletResponse(
            w.getId(), w.getBalance(),
            w.getCompany() != null ? w.getCompany().getId() : null,
            w.getCompany() != null ? w.getCompany().getCompanyName() : null
        );
    }

    public static WalletTransactionResponse toTransactionResponse(WalletTransaction t) {
        return new WalletTransactionResponse(
            t.getId(), t.getAmount(), t.getType(),
            t.getBalanceAfter(), t.getReference(), t.getTransactedAt()
        );
    }
}

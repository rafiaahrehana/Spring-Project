package com.startuphub.mapper;

import com.startuphub.dto.response.UserResponse;
import com.startuphub.entity.User;
import com.startuphub.location.mapper.AddressMapper;

public final class UserMapper {
    private UserMapper() {}

    public static UserResponse toResponse(User u) {
        return new UserResponse(
            u.getId(), u.getFirstName(), u.getLastName(),
            u.getEmail(), u.getPhone(), u.getRole(),
            u.isActive(), u.getImage(),
            AddressMapper.toResponse(u.getAddress()),
            u.getCreatedAt()
        );
    }
}

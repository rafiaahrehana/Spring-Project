package com.startuphub.mapper;

import com.startuphub.dto.response.EmployeeResponse;
import com.startuphub.entity.Employee;
import com.startuphub.entity.User;
import com.startuphub.location.mapper.AddressMapper;

public final class EmployeeMapper {
    private EmployeeMapper() {}

    public static EmployeeResponse toResponse(Employee e) {
        User u = e.getUser();
        return new EmployeeResponse(
            e.getId(),
            u != null ? u.getFirstName() : null,
            u != null ? u.getLastName() : null,
            u != null ? u.getEmail() : null,
            u != null ? u.getPhone() : null,
            u != null ? u.getImage() : null,
            u != null ? u.getRole() : null,
            u != null && u.isActive(),
            e.getDesignation(), e.getGender(),
            e.getDob(), e.getHireDate(),
            e.getCompany() != null ? e.getCompany().getId() : null,
            e.getCompany() != null ? e.getCompany().getCompanyName() : null,
            u != null ? AddressMapper.toResponse(u.getAddress()) : null,
            e.getCreatedAt()
        );
    }
}

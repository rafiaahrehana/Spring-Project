package com.startuphub.mapper;

import com.startuphub.dto.response.DocumentResponse;
import com.startuphub.entity.Document;

public final class DocumentMapper {
    private DocumentMapper() {}

    public static DocumentResponse toResponse(Document d) {
        return new DocumentResponse(
            d.getId(), d.getFileName(), d.getFileUrl(),
            d.getFileType(), d.getFileSizeBytes(), d.getLabel(), d.getNotes(),
            d.getServiceRequest() != null ? d.getServiceRequest().getId() : null,
            d.getUploadedBy() != null ? d.getUploadedBy().getId() : null,
            d.getCreatedAt()
        );
    }
}

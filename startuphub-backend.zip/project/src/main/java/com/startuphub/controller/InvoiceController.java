package com.startuphub.controller;

import com.startuphub.dto.request.InvoiceRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.InvoiceResponse;
import com.startuphub.service.impl.InvoiceServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
@Tag(name = "Invoices", description = "Invoice management")
public class InvoiceController {

    private final InvoiceServiceImpl invoiceService;

    @PostMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Create an invoice for a service request")
    public ResponseEntity<ApiResponse<InvoiceResponse>> create(
            @PathVariable Long companyId,
            @Valid @RequestBody InvoiceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Invoice created", invoiceService.create(companyId, request)));
    }

    @GetMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    public ResponseEntity<ApiResponse<Page<InvoiceResponse>>> getByCompany(
            @PathVariable Long companyId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            invoiceService.getByCompany(companyId, PageRequest.of(page, size))));
    }

    @GetMapping("/client/{clientId}")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','CLIENT')")
    public ResponseEntity<ApiResponse<Page<InvoiceResponse>>> getByClient(
            @PathVariable Long clientId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            invoiceService.getByClient(clientId, PageRequest.of(page, size))));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<InvoiceResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getById(id)));
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Cancel an invoice")
    public ResponseEntity<ApiResponse<InvoiceResponse>> cancel(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Invoice cancelled", invoiceService.cancel(id)));
    }
}

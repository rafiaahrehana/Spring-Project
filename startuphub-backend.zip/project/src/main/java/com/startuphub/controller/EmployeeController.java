package com.startuphub.controller;

import com.startuphub.dto.request.EmployeeRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.EmployeeResponse;
import com.startuphub.service.impl.EmployeeServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/employees")
@RequiredArgsConstructor
@Tag(name = "Employees", description = "Employee management")
public class EmployeeController {

    private final EmployeeServiceImpl employeeService;

    @PostMapping(value = "/company/{companyId}", consumes = "multipart/form-data")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Create an employee for a company")
    public ResponseEntity<ApiResponse<EmployeeResponse>> create(
            @PathVariable Long companyId,
            @Valid @RequestPart("data") EmployeeRequest request,
            @RequestPart(value = "image", required = false) MultipartFile image) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Employee created", employeeService.create(companyId, request, image)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Get employee by ID")
    public ResponseEntity<ApiResponse<EmployeeResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(employeeService.getById(id)));
    }

    @GetMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "List employees for a company (paginated)")
    public ResponseEntity<ApiResponse<Page<EmployeeResponse>>> getByCompany(
            @PathVariable Long companyId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            employeeService.getByCompany(companyId, PageRequest.of(page, size))));
    }

    @PutMapping(value = "/{id}", consumes = "multipart/form-data")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Update employee")
    public ResponseEntity<ApiResponse<EmployeeResponse>> update(
            @PathVariable Long id,
            @Valid @RequestPart("data") EmployeeRequest request,
            @RequestPart(value = "image", required = false) MultipartFile image) {
        return ResponseEntity.ok(ApiResponse.success("Employee updated", employeeService.update(id, request, image)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Delete employee")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        employeeService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Employee deleted", null));
    }
}

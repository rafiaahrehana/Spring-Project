package com.startuphub.controller;

import com.startuphub.dto.request.ChangePasswordRequest;
import com.startuphub.dto.request.UserProfileRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.UserResponse;
import com.startuphub.entity.User;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.location.entity.Address;
import com.startuphub.location.entity.PostOffice;
import com.startuphub.location.repository.PostOfficeRepository;
import com.startuphub.mapper.UserMapper;
import com.startuphub.repository.UserRepository;
import com.startuphub.security.SecurityUtil;
import com.startuphub.service.FileStorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "Users", description = "User profile and admin user management")
public class UserController {

    private final UserRepository userRepository;
    private final PostOfficeRepository postOfficeRepository;
    private final PasswordEncoder passwordEncoder;
    private final FileStorageService fileStorageService;
    private final SecurityUtil securityUtil;

    @GetMapping("/me")
    @Operation(summary = "Get current user profile")
    public ResponseEntity<ApiResponse<UserResponse>> getMyProfile() {
        return ResponseEntity.ok(ApiResponse.success(UserMapper.toResponse(securityUtil.getCurrentUser())));
    }

    @PutMapping(value = "/me", consumes = "multipart/form-data")
    @Transactional
    @Operation(summary = "Update current user profile")
    public ResponseEntity<ApiResponse<UserResponse>> updateMyProfile(
            @Valid @RequestPart("data") UserProfileRequest request,
            @RequestPart(value = "image", required = false) MultipartFile image) {
        User user = securityUtil.getCurrentUser();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhone(request.getPhone());
        if (image != null && !image.isEmpty())
            user.setImage(fileStorageService.store(image, "profile"));
        if (request.getPostOfficeId() != null) {
            PostOffice po = postOfficeRepository.findById(request.getPostOfficeId())
                .orElseThrow(() -> new BadRequestException("Post office not found"));
            Address address = user.getAddress() != null ? user.getAddress() : new Address();
            address.setHouseNo(request.getHouseNo());
            address.setRoad(request.getRoad());
            address.setPostOffice(po);
            user.setAddress(address);
        }
        userRepository.save(user);
        return ResponseEntity.ok(ApiResponse.success("Profile updated", UserMapper.toResponse(user)));
    }

    @PatchMapping("/me/change-password")
    @Transactional
    @Operation(summary = "Change current user password")
    public ResponseEntity<ApiResponse<Void>> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        User user = securityUtil.getCurrentUser();
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword()))
            throw new BadRequestException("Current password is incorrect");
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        return ResponseEntity.ok(ApiResponse.success("Password changed successfully", null));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Get any user by ID — Super Admin only")
    public ResponseEntity<ApiResponse<UserResponse>> getById(@PathVariable Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return ResponseEntity.ok(ApiResponse.success(UserMapper.toResponse(user)));
    }

    @PatchMapping("/{id}/toggle-active")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Transactional
    @Operation(summary = "Toggle user active/inactive — Super Admin only")
    public ResponseEntity<ApiResponse<Void>> toggleActive(@PathVariable Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        user.setActive(!user.isActive());
        userRepository.save(user);
        return ResponseEntity.ok(ApiResponse.success("User status updated", null));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Transactional
    @Operation(summary = "Delete a user — Super Admin only")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        userRepository.delete(user);
        return ResponseEntity.ok(ApiResponse.success("User deleted", null));
    }
}

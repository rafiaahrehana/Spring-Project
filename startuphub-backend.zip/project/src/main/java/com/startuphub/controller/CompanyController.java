package com.startuphub.controller;

import com.startuphub.dto.request.CompanyRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.CompanyResponse;
import com.startuphub.enums.SubscriptionPlan;
import com.startuphub.service.impl.CompanyServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/companies")
@RequiredArgsConstructor
@Tag(name = "Companies", description = "Company management — Super Admin only")
public class CompanyController {

    private final CompanyServiceImpl companyService;

    @PostMapping(consumes = "multipart/form-data")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Create a new company")
    public ResponseEntity<ApiResponse<CompanyResponse>> create(
            @RequestPart("data") CompanyRequest request,
            @RequestPart(value = "logo", required = false) MultipartFile logo) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Company created", companyService.create(request, logo)));
    }

    @GetMapping
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Get all companies")
    public ResponseEntity<ApiResponse<List<CompanyResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(companyService.getAll()));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Get company by ID")
    public ResponseEntity<ApiResponse<CompanyResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(companyService.getById(id)));
    }

    @GetMapping("/search")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Search companies by name")
    public ResponseEntity<ApiResponse<Page<CompanyResponse>>> search(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            companyService.search(query, PageRequest.of(page, size))));
    }

    @GetMapping("/plan/{plan}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Get companies by subscription plan")
    public ResponseEntity<ApiResponse<Page<CompanyResponse>>> getByPlan(
            @PathVariable SubscriptionPlan plan,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            companyService.getByPlan(plan, PageRequest.of(page, size))));
    }

    @PutMapping(value = "/{id}", consumes = "multipart/form-data")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER')")
    @Operation(summary = "Update company")
    public ResponseEntity<ApiResponse<CompanyResponse>> update(
            @PathVariable Long id,
            @RequestPart("data") CompanyRequest request,
            @RequestPart(value = "logo", required = false) MultipartFile logo) {
        return ResponseEntity.ok(ApiResponse.success("Company updated", companyService.update(id, request, logo)));
    }

    @PatchMapping("/{id}/activate")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Activate a company and set subscription plan")
    public ResponseEntity<ApiResponse<CompanyResponse>> activate(
            @PathVariable Long id,
            @RequestParam SubscriptionPlan plan,
            @RequestParam LocalDate start,
            @RequestParam LocalDate end) {
        return ResponseEntity.ok(ApiResponse.success("Company activated",
            companyService.activate(id, plan, start, end)));
    }

    @PatchMapping("/{id}/deactivate")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Deactivate a company")
    public ResponseEntity<ApiResponse<CompanyResponse>> deactivate(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Company deactivated", companyService.deactivate(id)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Delete a company")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        companyService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Company deleted", null));
    }
}

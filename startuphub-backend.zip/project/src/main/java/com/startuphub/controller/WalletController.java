package com.startuphub.controller;

import com.startuphub.dto.request.WalletRequest;
import com.startuphub.dto.response.*;
import com.startuphub.service.impl.WalletServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wallets")
@RequiredArgsConstructor
@Tag(name = "Wallet", description = "Wallet balance and transactions")
public class WalletController {

    private final WalletServiceImpl walletService;

    @GetMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Get wallet balance for a company")
    public ResponseEntity<ApiResponse<WalletResponse>> getBalance(@PathVariable Long companyId) {
        return ResponseEntity.ok(ApiResponse.success(walletService.getByCompany(companyId)));
    }

    @GetMapping("/company/{companyId}/transactions")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Get wallet transaction history")
    public ResponseEntity<ApiResponse<Page<WalletTransactionResponse>>> getTransactions(
            @PathVariable Long companyId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            walletService.getTransactions(companyId, PageRequest.of(page, size))));
    }

    @PatchMapping("/company/{companyId}/credit")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Credit wallet — Super Admin only")
    public ResponseEntity<ApiResponse<WalletResponse>> credit(
            @PathVariable Long companyId, @Valid @RequestBody WalletRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Wallet credited", walletService.credit(companyId, request)));
    }

    @PatchMapping("/company/{companyId}/debit")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Debit wallet — Super Admin only")
    public ResponseEntity<ApiResponse<WalletResponse>> debit(
            @PathVariable Long companyId, @Valid @RequestBody WalletRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Wallet debited", walletService.debit(companyId, request)));
    }

    @PostMapping("/pay-invoice/{invoiceId}/client/{clientId}")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','CLIENT')")
    @Operation(summary = "Pay an invoice from wallet balance")
    public ResponseEntity<ApiResponse<PaymentResponse>> payInvoice(
            @PathVariable Long invoiceId, @PathVariable Long clientId) {
        return ResponseEntity.ok(ApiResponse.success("Payment successful",
            walletService.payInvoiceFromWallet(invoiceId, clientId)));
    }
}

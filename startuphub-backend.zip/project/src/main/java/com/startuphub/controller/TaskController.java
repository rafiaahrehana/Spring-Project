package com.startuphub.controller;

import com.startuphub.dto.request.TaskRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.TaskResponse;
import com.startuphub.enums.TaskStatus;
import com.startuphub.service.impl.TaskServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
@Tag(name = "Tasks", description = "Task management within service requests")
public class TaskController {

    private final TaskServiceImpl taskService;

    @PostMapping("/request/{requestId}")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','EMPLOYEE')")
    @Operation(summary = "Create a task under a service request")
    public ResponseEntity<ApiResponse<TaskResponse>> create(
            @PathVariable Long requestId,
            @Valid @RequestBody TaskRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Task created", taskService.create(requestId, request)));
    }

    @GetMapping("/request/{requestId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "List tasks for a service request")
    public ResponseEntity<ApiResponse<List<TaskResponse>>> getByRequest(@PathVariable Long requestId) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getByRequest(requestId)));
    }

    @GetMapping("/employee/{employeeId}")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','EMPLOYEE')")
    @Operation(summary = "List tasks assigned to an employee")
    public ResponseEntity<ApiResponse<Page<TaskResponse>>> getByEmployee(
            @PathVariable Long employeeId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            taskService.getByEmployee(employeeId, PageRequest.of(page, size))));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<TaskResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(taskService.getById(id)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','EMPLOYEE')")
    public ResponseEntity<ApiResponse<TaskResponse>> update(
            @PathVariable Long id, @Valid @RequestBody TaskRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Task updated", taskService.update(id, request)));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','EMPLOYEE')")
    @Operation(summary = "Update task status")
    public ResponseEntity<ApiResponse<TaskResponse>> updateStatus(
            @PathVariable Long id, @RequestParam TaskStatus status) {
        return ResponseEntity.ok(ApiResponse.success("Status updated", taskService.updateStatus(id, status)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN')")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        taskService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Task deleted", null));
    }
}

package com.startuphub.controller;

import com.startuphub.dto.request.HubServiceRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.HubServiceResponse;
import com.startuphub.service.impl.HubServiceServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/services")
@RequiredArgsConstructor
@Tag(name = "Hub Services", description = "Service catalogue management")
public class HubServiceController {

    private final HubServiceServiceImpl hubServiceService;

    @PostMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Create a service for a company")
    public ResponseEntity<ApiResponse<HubServiceResponse>> create(
            @PathVariable Long companyId,
            @Valid @RequestBody HubServiceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Service created", hubServiceService.create(companyId, request)));
    }

    @GetMapping("/company/{companyId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "List services for a company")
    public ResponseEntity<ApiResponse<Page<HubServiceResponse>>> getByCompany(
            @PathVariable Long companyId,
            @RequestParam(required = false) Boolean activeOnly,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            hubServiceService.getByCompany(companyId, activeOnly, PageRequest.of(page, size))));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<HubServiceResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(hubServiceService.getById(id)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    public ResponseEntity<ApiResponse<HubServiceResponse>> update(
            @PathVariable Long id, @Valid @RequestBody HubServiceRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Service updated", hubServiceService.update(id, request)));
    }

    @PatchMapping("/{id}/toggle")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Toggle service active/inactive")
    public ResponseEntity<ApiResponse<HubServiceResponse>> toggle(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(hubServiceService.toggleActive(id)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER')")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        hubServiceService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Service deleted", null));
    }
}

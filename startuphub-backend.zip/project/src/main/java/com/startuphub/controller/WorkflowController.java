package com.startuphub.controller;

import com.startuphub.dto.request.WorkflowTemplateRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.WorkflowTemplateResponse;
import com.startuphub.service.impl.WorkflowServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workflows")
@RequiredArgsConstructor
@Tag(name = "Workflows", description = "Workflow template management")
public class WorkflowController {

    private final WorkflowServiceImpl workflowService;

    @PostMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Create a workflow template for a company")
    public ResponseEntity<ApiResponse<WorkflowTemplateResponse>> create(
            @PathVariable Long companyId,
            @Valid @RequestBody WorkflowTemplateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Workflow created", workflowService.create(companyId, request)));
    }

    @GetMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "List workflow templates for a company")
    public ResponseEntity<ApiResponse<List<WorkflowTemplateResponse>>> getByCompany(@PathVariable Long companyId) {
        return ResponseEntity.ok(ApiResponse.success(workflowService.getByCompany(companyId)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    public ResponseEntity<ApiResponse<WorkflowTemplateResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(workflowService.getById(id)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Update a workflow template and its stages")
    public ResponseEntity<ApiResponse<WorkflowTemplateResponse>> update(
            @PathVariable Long id, @Valid @RequestBody WorkflowTemplateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Workflow updated", workflowService.update(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER')")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        workflowService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Workflow deleted", null));
    }
}

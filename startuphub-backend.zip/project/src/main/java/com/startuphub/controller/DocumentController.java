package com.startuphub.controller;

import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.DocumentResponse;
import com.startuphub.entity.*;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.DocumentMapper;
import com.startuphub.repository.*;
import com.startuphub.security.SecurityUtil;
import com.startuphub.service.FileStorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
@RequiredArgsConstructor
@Tag(name = "Documents", description = "Document upload and management per service request")
public class DocumentController {

    private final DocumentRepository documentRepository;
    private final ServiceRequestRepository serviceRequestRepository;
    private final CompanyRepository companyRepository;
    private final FileStorageService fileStorageService;
    private final SecurityUtil securityUtil;

    @PostMapping(value = "/request/{requestId}", consumes = "multipart/form-data")
    @PreAuthorize("isAuthenticated()")
    @Transactional
    @Operation(summary = "Upload a document for a service request")
    public ResponseEntity<ApiResponse<DocumentResponse>> upload(
            @PathVariable Long requestId,
            @RequestPart("file") MultipartFile file,
            @RequestPart(value = "label", required = false) String label,
            @RequestPart(value = "notes", required = false) String notes) {
        ServiceRequest sr = serviceRequestRepository.findById(requestId)
            .orElseThrow(() -> new ResourceNotFoundException("Service request not found"));
        User uploader = securityUtil.getCurrentUser();
        String path = fileStorageService.store(file, "documents");

        Document doc = new Document();
        doc.setFileName(file.getOriginalFilename());
        doc.setFileUrl(path);
        doc.setFileType(file.getContentType());
        doc.setFileSizeBytes(file.getSize());
        doc.setLabel(label);
        doc.setNotes(notes);
        doc.setServiceRequest(sr);
        doc.setUploadedBy(uploader);
        doc.setCompany(sr.getCompany());
        documentRepository.save(doc);

        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Document uploaded", DocumentMapper.toResponse(doc)));
    }

    @GetMapping("/request/{requestId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "List all documents for a service request")
    public ResponseEntity<ApiResponse<List<DocumentResponse>>> getByRequest(@PathVariable Long requestId) {
        List<DocumentResponse> docs = documentRepository.findByServiceRequestId(requestId)
            .stream().map(DocumentMapper::toResponse).toList();
        return ResponseEntity.ok(ApiResponse.success(docs));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN')")
    @Transactional
    @Operation(summary = "Delete a document")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        Document doc = documentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Document not found with id: " + id));
        fileStorageService.delete(doc.getFileUrl());
        documentRepository.delete(doc);
        return ResponseEntity.ok(ApiResponse.success("Document deleted", null));
    }
}

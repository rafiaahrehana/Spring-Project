package com.startuphub.controller;

import com.startuphub.dto.request.AssignRequestRequest;
import com.startuphub.dto.request.ServiceRequestRequest;
import com.startuphub.dto.response.ApiResponse;
import com.startuphub.dto.response.ServiceRequestResponse;
import com.startuphub.enums.RequestStatus;
import com.startuphub.service.impl.ServiceRequestServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
@Tag(name = "Service Requests", description = "Service request lifecycle management")
public class ServiceRequestController {

    private final ServiceRequestServiceImpl serviceRequestService;

    @PostMapping("/company/{companyId}/client/{clientId}")
    @PreAuthorize("hasAnyRole('COMPANY_ADMIN','CLIENT','COMPANY_OWNER')")
    @Operation(summary = "Submit a new service request")
    public ResponseEntity<ApiResponse<ServiceRequestResponse>> create(
            @PathVariable Long companyId,
            @PathVariable Long clientId,
            @Valid @RequestBody ServiceRequestRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Request submitted", serviceRequestService.create(companyId, clientId, request)));
    }

    @GetMapping("/company/{companyId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_OWNER','COMPANY_ADMIN','EMPLOYEE')")
    @Operation(summary = "List all requests for a company")
    public ResponseEntity<ApiResponse<Page<ServiceRequestResponse>>> getByCompany(
            @PathVariable Long companyId,
            @RequestParam(required = false) RequestStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            serviceRequestService.getByCompany(companyId, status, PageRequest.of(page, size))));
    }

    @GetMapping("/client/{clientId}")
    @PreAuthorize("hasAnyRole('COMPANY_ADMIN','CLIENT','COMPANY_OWNER','EMPLOYEE')")
    @Operation(summary = "List all requests for a client")
    public ResponseEntity<ApiResponse<Page<ServiceRequestResponse>>> getByClient(
            @PathVariable Long clientId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            serviceRequestService.getByClient(clientId, PageRequest.of(page, size))));
    }

    @GetMapping("/employee/{employeeId}")
    @PreAuthorize("hasAnyRole('COMPANY_ADMIN','COMPANY_OWNER','EMPLOYEE')")
    @Operation(summary = "List requests assigned to an employee")
    public ResponseEntity<ApiResponse<Page<ServiceRequestResponse>>> getByEmployee(
            @PathVariable Long employeeId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(
            serviceRequestService.getByEmployee(employeeId, PageRequest.of(page, size))));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ServiceRequestResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(serviceRequestService.getById(id)));
    }

    @PatchMapping("/{id}/assign")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN')")
    @Operation(summary = "Assign a request to an employee")
    public ResponseEntity<ApiResponse<ServiceRequestResponse>> assign(
            @PathVariable Long id, @Valid @RequestBody AssignRequestRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Request assigned", serviceRequestService.assign(id, request)));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','EMPLOYEE')")
    @Operation(summary = "Update request status (state machine enforced)")
    public ResponseEntity<ApiResponse<ServiceRequestResponse>> updateStatus(
            @PathVariable Long id, @RequestParam RequestStatus status) {
        return ResponseEntity.ok(ApiResponse.success("Status updated", serviceRequestService.updateStatus(id, status)));
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('COMPANY_OWNER','COMPANY_ADMIN','CLIENT')")
    @Operation(summary = "Cancel a request")
    public ResponseEntity<ApiResponse<ServiceRequestResponse>> cancel(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Request cancelled", serviceRequestService.cancel(id)));
    }
}

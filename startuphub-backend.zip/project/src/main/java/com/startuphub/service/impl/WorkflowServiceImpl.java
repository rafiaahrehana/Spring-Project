package com.startuphub.service.impl;

import com.startuphub.dto.request.WorkflowTemplateRequest;
import com.startuphub.dto.response.WorkflowTemplateResponse;
import com.startuphub.entity.*;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.WorkflowMapper;
import com.startuphub.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WorkflowServiceImpl {

    private final WorkflowTemplateRepository workflowTemplateRepository;
    private final CompanyRepository companyRepository;

    @Transactional
    public WorkflowTemplateResponse create(Long companyId, WorkflowTemplateRequest request) {
        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found"));

        WorkflowTemplate template = new WorkflowTemplate();
        template.setName(request.getName());
        template.setDescription(request.getDescription());
        template.setCompany(company);
        template.setActive(true);

        List<WorkflowStage> stages = new ArrayList<>();
        for (int i = 0; i < request.getStages().size(); i++) {
            var stageReq = request.getStages().get(i);
            WorkflowStage stage = new WorkflowStage();
            stage.setName(stageReq.getName());
            stage.setDescription(stageReq.getDescription());
            stage.setEstimatedDays(stageReq.getEstimatedDays());
            stage.setStageOrder(i + 1);
            stage.setWorkflowTemplate(template);
            stages.add(stage);
        }
        template.setStages(stages);
        workflowTemplateRepository.save(template);

        return WorkflowMapper.toResponse(template);
    }

    public List<WorkflowTemplateResponse> getByCompany(Long companyId) {
        return workflowTemplateRepository.findByCompanyId(companyId)
            .stream().map(WorkflowMapper::toResponse).toList();
    }

    public WorkflowTemplateResponse getById(Long id) {
        return WorkflowMapper.toResponse(findById(id));
    }

    @Transactional
    public WorkflowTemplateResponse update(Long id, WorkflowTemplateRequest request) {
        WorkflowTemplate template = findById(id);
        template.setName(request.getName());
        template.setDescription(request.getDescription());
        template.getStages().clear();

        for (int i = 0; i < request.getStages().size(); i++) {
            var stageReq = request.getStages().get(i);
            WorkflowStage stage = new WorkflowStage();
            stage.setName(stageReq.getName());
            stage.setDescription(stageReq.getDescription());
            stage.setEstimatedDays(stageReq.getEstimatedDays());
            stage.setStageOrder(i + 1);
            stage.setWorkflowTemplate(template);
            template.getStages().add(stage);
        }
        return WorkflowMapper.toResponse(template);
    }

    @Transactional
    public void delete(Long id) {
        workflowTemplateRepository.delete(findById(id));
    }

    private WorkflowTemplate findById(Long id) {
        return workflowTemplateRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Workflow template not found with id: " + id));
    }
}

package com.startuphub.service.impl;

import com.startuphub.dto.request.ClientRequest;
import com.startuphub.dto.response.ClientResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.Role;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.location.entity.Address;
import com.startuphub.location.entity.PostOffice;
import com.startuphub.location.repository.PostOfficeRepository;
import com.startuphub.mapper.ClientMapper;
import com.startuphub.repository.*;
import com.startuphub.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class ClientServiceImpl {

    private final ClientRepository clientRepository;
    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final PostOfficeRepository postOfficeRepository;
    private final PasswordEncoder passwordEncoder;
    private final FileStorageService fileStorageService;

    @Transactional
    public ClientResponse create(Long companyId, ClientRequest request, MultipartFile image) {
        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found"));
        if (userRepository.existsByEmail(request.getEmail()))
            throw new BadRequestException("Email already registered");

        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(Role.CLIENT);
        user.setActive(true);
        if (request.getPostOfficeId() != null)
            user.setAddress(buildAddress(request.getPostOfficeId(), request.getHouseNo(), request.getRoad()));
        if (image != null && !image.isEmpty())
            user.setImage(fileStorageService.store(image, "client"));
        userRepository.save(user);

        Client client = new Client();
        client.setUser(user);
        client.setCompany(company);
        client.setBillingAddress(request.getBillingAddress());
        clientRepository.save(client);

        return ClientMapper.toResponse(client);
    }

    public ClientResponse getById(Long id) {
        return ClientMapper.toResponse(findById(id));
    }

    public Page<ClientResponse> getByCompany(Long companyId, Pageable pageable) {
        return clientRepository.findByCompanyId(companyId, pageable).map(ClientMapper::toResponse);
    }

    @Transactional
    public ClientResponse update(Long id, ClientRequest request, MultipartFile image) {
        Client client = findById(id);
        User user = client.getUser();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhone(request.getPhone());
        client.setBillingAddress(request.getBillingAddress());
        if (image != null && !image.isEmpty())
            user.setImage(fileStorageService.store(image, "client"));
        return ClientMapper.toResponse(client);
    }

    @Transactional
    public void delete(Long id) {
        Client client = findById(id);
        userRepository.delete(client.getUser());
        clientRepository.delete(client);
    }

    private Client findById(Long id) {
        return clientRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Client not found with id: " + id));
    }

    private Address buildAddress(Long postOfficeId, String houseNo, String road) {
        PostOffice po = postOfficeRepository.findById(postOfficeId)
            .orElseThrow(() -> new BadRequestException("Post office not found"));
        Address addr = new Address();
        addr.setHouseNo(houseNo);
        addr.setRoad(road);
        addr.setPostOffice(po);
        return addr;
    }
}

package com.startuphub.service.impl;

import com.startuphub.dto.request.InvoiceRequest;
import com.startuphub.dto.response.InvoiceResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.InvoiceStatus;
import com.startuphub.enums.NotificationType;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.InvoiceMapper;
import com.startuphub.repository.*;
import com.startuphub.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicLong;

@Service
@RequiredArgsConstructor
public class InvoiceServiceImpl {

    private final InvoiceRepository invoiceRepository;
    private final ServiceRequestRepository serviceRequestRepository;
    private final ClientRepository clientRepository;
    private final CompanyRepository companyRepository;
    private final PromoCodeRepository promoCodeRepository;
    private final NotificationService notificationService;

    private static final AtomicLong SEQUENCE = new AtomicLong(System.currentTimeMillis() % 100000);

    @Transactional
    public InvoiceResponse create(Long companyId, InvoiceRequest request) {
        ServiceRequest sr = serviceRequestRepository.findById(request.getServiceRequestId())
            .orElseThrow(() -> new ResourceNotFoundException("Service request not found"));
        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found"));

        double subtotal = request.getSubtotal();
        double discount = request.getDiscountAmount();

        if (request.getPromoCode() != null) {
            PromoCode promo = promoCodeRepository.findByCodeAndCompanyId(request.getPromoCode(), companyId)
                .orElseThrow(() -> new BadRequestException("Invalid promo code"));
            validatePromo(promo, subtotal);
            discount += switch (promo.getDiscountType()) {
                case PERCENT -> subtotal * promo.getDiscountValue() / 100;
                case FIXED -> promo.getDiscountValue();
            };
            promo.setUsedCount(promo.getUsedCount() + 1);
        }

        double total = subtotal - discount + request.getTaxAmount();

        Invoice invoice = new Invoice();
        invoice.setInvoiceNumber(generateInvoiceNumber(companyId));
        invoice.setStatus(InvoiceStatus.SENT);
        invoice.setSubtotal(subtotal);
        invoice.setDiscountAmount(discount);
        invoice.setTaxAmount(request.getTaxAmount());
        invoice.setTotalAmount(total);
        invoice.setPaidAmount(0.0);
        invoice.setIssueDate(LocalDate.now());
        invoice.setDueDate(request.getDueDate() != null ? request.getDueDate() : LocalDate.now().plusDays(30));
        invoice.setNotes(request.getNotes());
        invoice.setServiceRequest(sr);
        invoice.setClient(sr.getClient());
        invoice.setCompany(company);
        invoiceRepository.save(invoice);

        notificationService.send(sr.getClient().getUser(),
            "Invoice #" + invoice.getInvoiceNumber(),
            "An invoice of BDT " + total + " has been issued for your request.",
            NotificationType.PAYMENT_DUE, sr, company);

        return InvoiceMapper.toResponse(invoice);
    }

    public Page<InvoiceResponse> getByCompany(Long companyId, Pageable pageable) {
        return invoiceRepository.findByCompanyId(companyId, pageable).map(InvoiceMapper::toResponse);
    }

    public Page<InvoiceResponse> getByClient(Long clientId, Pageable pageable) {
        return invoiceRepository.findByClientId(clientId, pageable).map(InvoiceMapper::toResponse);
    }

    public InvoiceResponse getById(Long id) {
        return InvoiceMapper.toResponse(findById(id));
    }

    @Transactional
    public InvoiceResponse cancel(Long id) {
        Invoice invoice = findById(id);
        if (invoice.getStatus() == InvoiceStatus.PAID)
            throw new BadRequestException("Cannot cancel a paid invoice");
        invoice.setStatus(InvoiceStatus.CANCELLED);
        return InvoiceMapper.toResponse(invoice);
    }

    private Invoice findById(Long id) {
        return invoiceRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with id: " + id));
    }

    private void validatePromo(PromoCode promo, double subtotal) {
        if (!promo.isActive()) throw new BadRequestException("Promo code is inactive");
        if (promo.getValidUntil() != null && LocalDate.now().isAfter(promo.getValidUntil()))
            throw new BadRequestException("Promo code has expired");
        if (promo.getMaxUses() != null && promo.getUsedCount() >= promo.getMaxUses())
            throw new BadRequestException("Promo code usage limit reached");
        if (promo.getMinOrderAmount() != null && subtotal < promo.getMinOrderAmount())
            throw new BadRequestException("Order total does not meet minimum for this promo code");
    }

    private String generateInvoiceNumber(Long companyId) {
        return "INV-" + companyId + "-" + DateTimeFormatter.ofPattern("yyyyMM").format(LocalDate.now())
            + "-" + String.format("%05d", SEQUENCE.incrementAndGet());
    }
}

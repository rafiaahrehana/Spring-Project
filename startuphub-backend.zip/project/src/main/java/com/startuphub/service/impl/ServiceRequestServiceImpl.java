package com.startuphub.service.impl;

import com.startuphub.dto.request.AssignRequestRequest;
import com.startuphub.dto.request.ServiceRequestRequest;
import com.startuphub.dto.response.ServiceRequestResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.NotificationType;
import com.startuphub.enums.RequestStatus;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.ServiceRequestMapper;
import com.startuphub.repository.*;
import com.startuphub.security.SecurityUtil;
import com.startuphub.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class ServiceRequestServiceImpl {

    private final ServiceRequestRepository serviceRequestRepository;
    private final HubServiceRepository hubServiceRepository;
    private final ClientRepository clientRepository;
    private final CompanyRepository companyRepository;
    private final EmployeeRepository employeeRepository;
    private final NotificationService notificationService;
    private final SecurityUtil securityUtil;

    @Transactional
    public ServiceRequestResponse create(Long companyId, Long clientId, ServiceRequestRequest request) {
        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found"));
        Client client = clientRepository.findById(clientId)
            .orElseThrow(() -> new ResourceNotFoundException("Client not found"));
        HubService hubService = hubServiceRepository.findById(request.getHubServiceId())
            .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        ServiceRequest sr = new ServiceRequest();
        sr.setTitle(request.getTitle());
        sr.setDescription(request.getDescription());
        sr.setStatus(RequestStatus.PENDING);
        sr.setPriority(request.getPriority());
        sr.setDeadline(request.getDeadline());
        sr.setAgreedPrice(request.getAgreedPrice() != null ? request.getAgreedPrice() : hubService.getPrice());
        sr.setSlaHours(hubService.getEstimatedDays() != null ? hubService.getEstimatedDays() * 8 : null);
        sr.setHubService(hubService);
        sr.setClient(client);
        sr.setCompany(company);
        sr.setCurrentStage(0);
        serviceRequestRepository.save(sr);

        notificationService.send(client.getUser(),
            "Request Submitted",
            "Your request '" + sr.getTitle() + "' has been submitted successfully.",
            NotificationType.REQUEST_SUBMITTED, sr, company);

        return ServiceRequestMapper.toResponse(sr);
    }

    public Page<ServiceRequestResponse> getByCompany(Long companyId, RequestStatus status, Pageable pageable) {
        if (status != null)
            return serviceRequestRepository.findByCompanyIdAndStatus(companyId, status, pageable)
                .map(ServiceRequestMapper::toResponse);
        return serviceRequestRepository.findByCompanyId(companyId, pageable)
            .map(ServiceRequestMapper::toResponse);
    }

    public Page<ServiceRequestResponse> getByClient(Long clientId, Pageable pageable) {
        return serviceRequestRepository.findByClientId(clientId, pageable)
            .map(ServiceRequestMapper::toResponse);
    }

    public Page<ServiceRequestResponse> getByEmployee(Long employeeId, Pageable pageable) {
        return serviceRequestRepository.findByAssignedEmployeeId(employeeId, pageable)
            .map(ServiceRequestMapper::toResponse);
    }

    public ServiceRequestResponse getById(Long id) {
        return ServiceRequestMapper.toResponse(findById(id));
    }

    @Transactional
    public ServiceRequestResponse assign(Long id, AssignRequestRequest request) {
        ServiceRequest sr = findById(id);
        Employee employee = employeeRepository.findById(request.getEmployeeId())
            .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        sr.setAssignedEmployee(employee);
        sr.setStatus(RequestStatus.ASSIGNED);
        sr.setAssignedAt(LocalDateTime.now());

        notificationService.send(employee.getUser(),
            "Task Assigned", "You have been assigned to request: " + sr.getTitle(),
            NotificationType.REQUEST_ASSIGNED, sr, sr.getCompany());

        return ServiceRequestMapper.toResponse(sr);
    }

    @Transactional
    public ServiceRequestResponse updateStatus(Long id, RequestStatus newStatus) {
        ServiceRequest sr = findById(id);
        validateTransition(sr.getStatus(), newStatus);
        sr.setStatus(newStatus);
        if (newStatus == RequestStatus.COMPLETED) sr.setCompletedAt(LocalDateTime.now());

        User clientUser = sr.getClient().getUser();
        notificationService.send(clientUser,
            "Request " + newStatus.name().replace("_", " "),
            "Your request '" + sr.getTitle() + "' status changed to " + newStatus,
            newStatus == RequestStatus.COMPLETED
                ? NotificationType.COMPLETED : NotificationType.REQUEST_UPDATED,
            sr, sr.getCompany());

        return ServiceRequestMapper.toResponse(sr);
    }

    @Transactional
    public ServiceRequestResponse cancel(Long id) {
        ServiceRequest sr = findById(id);
        if (sr.getStatus() == RequestStatus.COMPLETED)
            throw new BadRequestException("Cannot cancel a completed request");
        sr.setStatus(RequestStatus.CANCELLED);
        return ServiceRequestMapper.toResponse(sr);
    }

    private void validateTransition(RequestStatus current, RequestStatus next) {
        boolean valid = switch (current) {
            case PENDING -> next == RequestStatus.ASSIGNED || next == RequestStatus.REJECTED || next == RequestStatus.CANCELLED;
            case ASSIGNED -> next == RequestStatus.IN_PROGRESS || next == RequestStatus.CANCELLED;
            case IN_PROGRESS -> next == RequestStatus.REVIEW || next == RequestStatus.CANCELLED;
            case REVIEW -> next == RequestStatus.COMPLETED || next == RequestStatus.IN_PROGRESS;
            default -> false;
        };
        if (!valid)
            throw new BadRequestException("Invalid status transition: " + current + " -> " + next);
    }

    private ServiceRequest findById(Long id) {
        return serviceRequestRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Service request not found with id: " + id));
    }
}

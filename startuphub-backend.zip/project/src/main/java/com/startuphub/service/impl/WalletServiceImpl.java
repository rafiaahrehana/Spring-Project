package com.startuphub.service.impl;

import com.startuphub.dto.request.PaymentRequest;
import com.startuphub.dto.request.WalletRequest;
import com.startuphub.dto.response.PaymentResponse;
import com.startuphub.dto.response.WalletResponse;
import com.startuphub.dto.response.WalletTransactionResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.*;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.PaymentMapper;
import com.startuphub.mapper.WalletMapper;
import com.startuphub.repository.*;
import com.startuphub.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class WalletServiceImpl {

    private final WalletRepository walletRepository;
    private final WalletTransactionRepository walletTransactionRepository;
    private final InvoiceRepository invoiceRepository;
    private final PaymentRepository paymentRepository;
    private final ClientRepository clientRepository;
    private final CompanyRepository companyRepository;
    private final NotificationService notificationService;

    public WalletResponse getByCompany(Long companyId) {
        return WalletMapper.toResponse(findWallet(companyId));
    }

    public Page<WalletTransactionResponse> getTransactions(Long companyId, Pageable pageable) {
        Wallet wallet = findWallet(companyId);
        return walletTransactionRepository.findByWalletId(wallet.getId(), pageable)
            .map(WalletMapper::toTransactionResponse);
    }

    @Transactional
    public WalletResponse credit(Long companyId, WalletRequest request) {
        if (request.getAmount() <= 0) throw new BadRequestException("Amount must be positive");
        Wallet wallet = findWallet(companyId);
        wallet.setBalance(wallet.getBalance() + request.getAmount());
        saveTransaction(wallet, request.getAmount(), WalletTransactionType.CREDIT,
            wallet.getBalance(), request.getReference());
        return WalletMapper.toResponse(wallet);
    }

    @Transactional
    public WalletResponse debit(Long companyId, WalletRequest request) {
        if (request.getAmount() <= 0) throw new BadRequestException("Amount must be positive");
        Wallet wallet = findWallet(companyId);
        if (wallet.getBalance() < request.getAmount())
            throw new BadRequestException("Insufficient wallet balance");
        wallet.setBalance(wallet.getBalance() - request.getAmount());
        saveTransaction(wallet, request.getAmount(), WalletTransactionType.DEBIT,
            wallet.getBalance(), request.getReference());
        return WalletMapper.toResponse(wallet);
    }

    @Transactional
    public PaymentResponse payInvoiceFromWallet(Long invoiceId, Long clientId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
            .orElseThrow(() -> new ResourceNotFoundException("Invoice not found"));
        if (invoice.getStatus() == InvoiceStatus.PAID)
            throw new BadRequestException("Invoice already paid");

        double remaining = invoice.getTotalAmount() - invoice.getPaidAmount();
        Company company = invoice.getCompany();
        Wallet wallet = findWallet(company.getId());

        if (wallet.getBalance() < remaining)
            throw new BadRequestException("Insufficient wallet balance to pay invoice");

        wallet.setBalance(wallet.getBalance() - remaining);
        saveTransaction(wallet, remaining, WalletTransactionType.DEBIT, wallet.getBalance(),
            "Invoice #" + invoice.getInvoiceNumber());

        invoice.setPaidAmount(invoice.getTotalAmount());
        invoice.setStatus(InvoiceStatus.PAID);

        Client client = clientRepository.findById(clientId)
            .orElseThrow(() -> new ResourceNotFoundException("Client not found"));

        Payment payment = new Payment();
        payment.setAmount(remaining);
        payment.setPaymentMethod(PaymentMethod.WALLET);
        payment.setStatus(PaymentStatus.COMPLETED);
        payment.setPaidAt(LocalDateTime.now());
        payment.setInvoice(invoice);
        payment.setClient(client);
        payment.setCompany(company);
        paymentRepository.save(payment);

        notificationService.send(client.getUser(),
            "Payment Confirmed", "Your payment of BDT " + remaining + " for invoice #"
                + invoice.getInvoiceNumber() + " was successful.",
            NotificationType.PAYMENT_RECEIVED,
            invoice.getServiceRequest(), company);

        return PaymentMapper.toResponse(payment);
    }

    private Wallet findWallet(Long companyId) {
        return walletRepository.findByCompanyId(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found for company: " + companyId));
    }

    private void saveTransaction(Wallet wallet, Double amount,
                                  WalletTransactionType type, Double balanceAfter, String reference) {
        WalletTransaction tx = WalletTransaction.builder()
            .wallet(wallet).amount(amount).type(type)
            .balanceAfter(balanceAfter).reference(reference).build();
        walletTransactionRepository.save(tx);
    }
}

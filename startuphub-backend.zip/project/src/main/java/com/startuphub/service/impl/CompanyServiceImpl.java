package com.startuphub.service.impl;

import com.startuphub.dto.request.CompanyRequest;
import com.startuphub.dto.response.CompanyResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.Role;
import com.startuphub.enums.SubscriptionPlan;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.location.entity.Address;
import com.startuphub.location.entity.PostOffice;
import com.startuphub.location.repository.PostOfficeRepository;
import com.startuphub.mapper.CompanyMapper;
import com.startuphub.repository.*;
import com.startuphub.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CompanyServiceImpl {

    private final CompanyRepository companyRepository;
    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final EmployeeRepository employeeRepository;
    private final ClientRepository clientRepository;
    private final PostOfficeRepository postOfficeRepository;
    private final PasswordEncoder passwordEncoder;
    private final FileStorageService fileStorageService;

    @Transactional
    public CompanyResponse create(CompanyRequest request, MultipartFile logo) {
        if (companyRepository.existsBySubdomain(request.getSubdomain()))
            throw new BadRequestException("Subdomain already taken");
        if (userRepository.existsByEmail(request.getEmail()))
            throw new BadRequestException("Email already registered");

        User owner = buildUser(request);
        if (request.getPostOfficeId() != null)
            owner.setAddress(buildAddress(request.getPostOfficeId(), request.getHouseNo(), request.getRoad()));
        userRepository.save(owner);

        Company company = new Company();
        company.setCompanyName(request.getCompanyName());
        company.setCompanyEmail(request.getCompanyEmail());
        company.setCompanyPhone(request.getCompanyPhone());
        company.setSubdomain(request.getSubdomain());
        company.setWebsite(request.getWebsite());
        company.setUser(owner);
        company.setSubscriptionPlan(request.getSubscriptionPlan() != null
            ? request.getSubscriptionPlan() : SubscriptionPlan.FREE);
        company.setSubscriptionStart(request.getSubscriptionStart());
        company.setSubscriptionEnd(request.getSubscriptionEnd());
        company.setActive(false);

        if (logo != null && !logo.isEmpty())
            company.setLogo(fileStorageService.store(logo, "company"));
        companyRepository.save(company);

        Wallet wallet = new Wallet();
        wallet.setBalance(0.0);
        wallet.setCompany(company);
        walletRepository.save(wallet);

        return CompanyMapper.toResponse(company);
    }

    public CompanyResponse getById(Long id) {
        return CompanyMapper.toResponse(findById(id));
    }

    public List<CompanyResponse> getAll() {
        return companyRepository.findAll().stream().map(CompanyMapper::toResponse).toList();
    }

    public Page<CompanyResponse> search(String query, Pageable pageable) {
        return companyRepository.findByCompanyNameContainingIgnoreCase(query, pageable)
            .map(CompanyMapper::toResponse);
    }

    public Page<CompanyResponse> getByPlan(SubscriptionPlan plan, Pageable pageable) {
        return companyRepository.findBySubscriptionPlan(plan, pageable).map(CompanyMapper::toResponse);
    }

    @Transactional
    public CompanyResponse update(Long id, CompanyRequest request, MultipartFile logo) {
        Company company = findById(id);
        company.setCompanyName(request.getCompanyName());
        company.setCompanyEmail(request.getCompanyEmail());
        company.setCompanyPhone(request.getCompanyPhone());
        company.setWebsite(request.getWebsite());
        if (logo != null && !logo.isEmpty())
            company.setLogo(fileStorageService.store(logo, "company"));
        return CompanyMapper.toResponse(company);
    }

    @Transactional
    public CompanyResponse activate(Long id, SubscriptionPlan plan,
                                     java.time.LocalDate start, java.time.LocalDate end) {
        Company company = findById(id);
        company.setActive(true);
        company.setSubscriptionPlan(plan);
        company.setSubscriptionStart(start);
        company.setSubscriptionEnd(end);
        return CompanyMapper.toResponse(company);
    }

    @Transactional
    public CompanyResponse deactivate(Long id) {
        Company company = findById(id);
        company.setActive(false);
        return CompanyMapper.toResponse(company);
    }

    @Transactional
    public void delete(Long id) {
        Company company = findById(id);
        if (employeeRepository.existsByCompanyId(id))
            throw new BadRequestException("Cannot delete company with existing employees");
        if (clientRepository.existsByCompanyId(id))
            throw new BadRequestException("Cannot delete company with existing clients");
        if (company.getUser() != null) userRepository.delete(company.getUser());
        companyRepository.delete(company);
    }

    private Company findById(Long id) {
        return companyRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found with id: " + id));
    }

    private User buildUser(CompanyRequest req) {
        User u = new User();
        u.setFirstName(req.getFirstName());
        u.setLastName(req.getLastName());
        u.setEmail(req.getEmail());
        u.setPhone(req.getPhone());
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        u.setRole(Role.COMPANY_OWNER);
        u.setActive(true);
        return u;
    }

    private Address buildAddress(Long postOfficeId, String houseNo, String road) {
        PostOffice po = postOfficeRepository.findById(postOfficeId)
            .orElseThrow(() -> new BadRequestException("Post office not found"));
        Address addr = new Address();
        addr.setHouseNo(houseNo);
        addr.setRoad(road);
        addr.setPostOffice(po);
        return addr;
    }
}

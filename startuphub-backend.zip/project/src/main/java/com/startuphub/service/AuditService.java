package com.startuphub.service;

import com.startuphub.entity.*;
import com.startuphub.enums.AuditAction;
import com.startuphub.enums.AuditEntityType;
import com.startuphub.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    @Async
    @Transactional
    public void log(AuditEntityType entityType, Long entityId, AuditAction action,
                    String oldValue, String newValue, User performedBy, Company company) {
        AuditLog log = AuditLog.builder()
            .entityType(entityType).entityId(entityId)
            .action(action).oldValue(oldValue).newValue(newValue)
            .performedBy(performedBy).company(company)
            .build();
        auditLogRepository.save(log);
    }
}

package com.startuphub.service.impl;

import com.startuphub.dto.request.TaskRequest;
import com.startuphub.dto.response.TaskResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.NotificationType;
import com.startuphub.enums.TaskStatus;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.TaskMapper;
import com.startuphub.repository.*;
import com.startuphub.security.SecurityUtil;
import com.startuphub.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TaskServiceImpl {

    private final TaskRepository taskRepository;
    private final ServiceRequestRepository serviceRequestRepository;
    private final EmployeeRepository employeeRepository;
    private final NotificationService notificationService;
    private final SecurityUtil securityUtil;

    @Transactional
    public TaskResponse create(Long requestId, TaskRequest request) {
        ServiceRequest sr = serviceRequestRepository.findById(requestId)
            .orElseThrow(() -> new ResourceNotFoundException("Service request not found"));

        User currentUser = securityUtil.getCurrentUser();
        Employee creator = employeeRepository.findByUserId(currentUser.getId()).orElse(null);

        Task task = new Task();
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setPriority(request.getPriority());
        task.setDueDate(request.getDueDate());
        task.setNotes(request.getNotes());
        task.setStatus(TaskStatus.PENDING);
        task.setServiceRequest(sr);
        task.setCreatedBy(creator);

        if (request.getAssignedEmployeeId() != null) {
            Employee emp = employeeRepository.findById(request.getAssignedEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
            task.setAssignedEmployee(emp);

            notificationService.send(emp.getUser(),
                "Task Assigned", "You have a new task: " + task.getTitle(),
                NotificationType.TASK_ASSIGNED, sr, sr.getCompany());
        }

        taskRepository.save(task);
        return TaskMapper.toResponse(task);
    }

    public List<TaskResponse> getByRequest(Long requestId) {
        return taskRepository.findByServiceRequestId(requestId).stream()
            .map(TaskMapper::toResponse).toList();
    }

    public Page<TaskResponse> getByEmployee(Long employeeId, Pageable pageable) {
        return taskRepository.findByAssignedEmployeeId(employeeId, pageable)
            .map(TaskMapper::toResponse);
    }

    public TaskResponse getById(Long id) {
        return TaskMapper.toResponse(findById(id));
    }

    @Transactional
    public TaskResponse updateStatus(Long id, TaskStatus status) {
        Task task = findById(id);
        task.setStatus(status);
        if (status == TaskStatus.COMPLETED) task.setCompletedAt(LocalDateTime.now());
        return TaskMapper.toResponse(task);
    }

    @Transactional
    public TaskResponse update(Long id, TaskRequest request) {
        Task task = findById(id);
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setPriority(request.getPriority());
        task.setDueDate(request.getDueDate());
        task.setNotes(request.getNotes());
        if (request.getAssignedEmployeeId() != null) {
            Employee emp = employeeRepository.findById(request.getAssignedEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
            task.setAssignedEmployee(emp);
        }
        return TaskMapper.toResponse(task);
    }

    @Transactional
    public void delete(Long id) {
        taskRepository.delete(findById(id));
    }

    private Task findById(Long id) {
        return taskRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + id));
    }
}

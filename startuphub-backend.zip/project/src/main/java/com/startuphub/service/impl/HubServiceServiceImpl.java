package com.startuphub.service.impl;

import com.startuphub.dto.request.HubServiceRequest;
import com.startuphub.dto.response.HubServiceResponse;
import com.startuphub.entity.*;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.mapper.HubServiceMapper;
import com.startuphub.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class HubServiceServiceImpl {

    private final HubServiceRepository hubServiceRepository;
    private final CompanyRepository companyRepository;
    private final WorkflowTemplateRepository workflowTemplateRepository;

    @Transactional
    public HubServiceResponse create(Long companyId, HubServiceRequest request) {
        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found"));

        HubService service = new HubService();
        service.setName(request.getName());
        service.setDescription(request.getDescription());
        service.setIconUrl(request.getIconUrl());
        service.setPrice(request.getPrice());
        service.setPriceType(request.getPriceType());
        service.setEstimatedDays(request.getEstimatedDays());
        service.setDefaultPriority(request.getDefaultPriority());
        service.setCompany(company);
        service.setActive(true);

        if (request.getWorkflowTemplateId() != null) {
            workflowTemplateRepository.findById(request.getWorkflowTemplateId())
                .ifPresent(service::setWorkflowTemplate);
        }

        return HubServiceMapper.toResponse(hubServiceRepository.save(service));
    }

    public Page<HubServiceResponse> getByCompany(Long companyId, Boolean activeOnly, Pageable pageable) {
        if (Boolean.TRUE.equals(activeOnly))
            return hubServiceRepository.findByCompanyIdAndActive(companyId, true, pageable)
                .map(HubServiceMapper::toResponse);
        return hubServiceRepository.findByCompanyId(companyId, pageable).map(HubServiceMapper::toResponse);
    }

    public HubServiceResponse getById(Long id) {
        return HubServiceMapper.toResponse(findById(id));
    }

    @Transactional
    public HubServiceResponse update(Long id, HubServiceRequest request) {
        HubService service = findById(id);
        service.setName(request.getName());
        service.setDescription(request.getDescription());
        service.setIconUrl(request.getIconUrl());
        service.setPrice(request.getPrice());
        service.setPriceType(request.getPriceType());
        service.setEstimatedDays(request.getEstimatedDays());
        service.setDefaultPriority(request.getDefaultPriority());
        return HubServiceMapper.toResponse(service);
    }

    @Transactional
    public HubServiceResponse toggleActive(Long id) {
        HubService service = findById(id);
        service.setActive(!service.isActive());
        return HubServiceMapper.toResponse(service);
    }

    @Transactional
    public void delete(Long id) {
        hubServiceRepository.delete(findById(id));
    }

    private HubService findById(Long id) {
        return hubServiceRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Service not found with id: " + id));
    }
}

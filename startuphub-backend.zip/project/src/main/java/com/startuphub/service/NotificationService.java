package com.startuphub.service;

import com.startuphub.entity.*;
import com.startuphub.enums.NotificationType;
import com.startuphub.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    @Async
    @Transactional
    public void send(User recipient, String title, String message,
                     NotificationType type, ServiceRequest serviceRequest, Company company) {
        Notification n = new Notification();
        n.setRecipient(recipient);
        n.setTitle(title);
        n.setMessage(message);
        n.setType(type);
        n.setServiceRequest(serviceRequest);
        n.setCompany(company);
        notificationRepository.save(n);
    }

    @Async
    @Transactional
    public void send(User recipient, String title, String message,
                     NotificationType type, Company company) {
        send(recipient, title, message, type, null, company);
    }
}

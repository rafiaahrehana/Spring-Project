package com.startuphub.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Value("${app.frontend-url}")
    private String frontendUrl;

    @Async
    public void sendHtml(String to, String subject, String body) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setFrom(fromEmail);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(body, true);
            mailSender.send(message);
            log.info("Email sent to {}: {}", to, subject);
        } catch (MessagingException e) {
            log.error("Failed to send email to {}: {}", to, e.getMessage());
        }
    }

    public void sendVerificationEmail(String to, String name, String token) {
        String link = frontendUrl + "/verify-email?token=" + token;
        sendHtml(to, "Verify your StartupHub account",
            buildEmail("Verify your email", "Welcome, " + name + "!",
                "Please verify your email address to activate your account and start your 14-day free trial.",
                link, "Verify Email", "#2563EB"));
    }

    public void sendPasswordResetEmail(String to, String name, String token) {
        String link = frontendUrl + "/reset-password?token=" + token;
        sendHtml(to, "Reset your StartupHub password",
            buildEmail("Password Reset", "Hi " + name + ",",
                "We received a request to reset your password. This link expires in 15 minutes. If you did not request this, ignore this email.",
                link, "Reset Password", "#EF4444"));
    }

    public void sendWelcomeEmail(String to, String name, String companyName) {
        String link = frontendUrl + "/dashboard";
        sendHtml(to, "Welcome to StartupHub",
            buildEmail("Account Activated", "Welcome, " + name + "!",
                "Your account for <strong>" + companyName + "</strong> is now active. Your 14-day free trial has started.",
                link, "Go to Dashboard", "#2563EB"));
    }

    public void sendTrialExpiringEmail(String to, String name, String companyName, int daysLeft) {
        String link = frontendUrl + "/billing";
        sendHtml(to, "Your StartupHub trial ends in " + daysLeft + " day(s)",
            buildEmail("Trial Ending Soon", "Hi " + name + ",",
                "Your free trial for <strong>" + companyName + "</strong> ends in <strong>"
                    + daysLeft + " day(s)</strong>. Subscribe now to keep uninterrupted access.",
                link, "Choose a Plan", "#F59E0B"));
    }

    private String buildEmail(String header, String greeting, String body,
                               String ctaLink, String ctaText, String ctaColor) {
        return "<div style='font-family:Arial,sans-serif;max-width:600px;margin:auto'>"
            + "<div style='background:#1E3A5F;padding:28px;text-align:center'>"
            + "<h1 style='color:#fff;margin:0'>StartupHub</h1>"
            + "<p style='color:#93C5FD;margin:6px 0 0'>" + header + "</p></div>"
            + "<div style='padding:32px;color:#334155'>"
            + "<h2 style='color:#0f172a;margin-top:0'>" + greeting + "</h2>"
            + "<p style='line-height:1.7'>" + body + "</p>"
            + "<div style='text-align:center;margin:28px 0'>"
            + "<a href='" + ctaLink + "' style='display:inline-block;background:" + ctaColor
            + ";color:#fff;text-decoration:none;padding:13px 28px;border-radius:8px;font-weight:600'>"
            + ctaText + "</a></div></div>"
            + "<div style='background:#f8fafc;padding:14px;text-align:center;border-top:1px solid #e2e8f0'>"
            + "<p style='color:#64748b;font-size:12px;margin:0'>© 2026 StartupHub. All rights reserved.</p>"
            + "</div></div>";
    }
}

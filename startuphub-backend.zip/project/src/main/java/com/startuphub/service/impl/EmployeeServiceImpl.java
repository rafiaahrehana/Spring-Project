package com.startuphub.service.impl;

import com.startuphub.dto.request.EmployeeRequest;
import com.startuphub.dto.response.EmployeeResponse;
import com.startuphub.entity.*;
import com.startuphub.enums.Role;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.location.entity.Address;
import com.startuphub.location.entity.PostOffice;
import com.startuphub.location.repository.PostOfficeRepository;
import com.startuphub.mapper.EmployeeMapper;
import com.startuphub.repository.*;
import com.startuphub.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl {

    private final EmployeeRepository employeeRepository;
    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final PostOfficeRepository postOfficeRepository;
    private final PasswordEncoder passwordEncoder;
    private final FileStorageService fileStorageService;

    @Transactional
    public EmployeeResponse create(Long companyId, EmployeeRequest request, MultipartFile image) {
        Company company = companyRepository.findById(companyId)
            .orElseThrow(() -> new ResourceNotFoundException("Company not found"));
        if (userRepository.existsByEmail(request.getEmail()))
            throw new BadRequestException("Email already registered");

        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole() != null ? request.getRole() : Role.EMPLOYEE);
        user.setActive(true);
        if (request.getPostOfficeId() != null)
            user.setAddress(buildAddress(request.getPostOfficeId(), request.getHouseNo(), request.getRoad()));
        if (image != null && !image.isEmpty())
            user.setImage(fileStorageService.store(image, "employee"));
        userRepository.save(user);

        Employee employee = new Employee();
        employee.setUser(user);
        employee.setCompany(company);
        employee.setDob(request.getDob());
        employee.setGender(request.getGender());
        employee.setDesignation(request.getDesignation());
        employee.setHireDate(request.getHireDate());
        employeeRepository.save(employee);

        return EmployeeMapper.toResponse(employee);
    }

    public EmployeeResponse getById(Long id) {
        return EmployeeMapper.toResponse(findById(id));
    }

    public Page<EmployeeResponse> getByCompany(Long companyId, Pageable pageable) {
        return employeeRepository.findByCompanyId(companyId, pageable).map(EmployeeMapper::toResponse);
    }

    @Transactional
    public EmployeeResponse update(Long id, EmployeeRequest request, MultipartFile image) {
        Employee employee = findById(id);
        User user = employee.getUser();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhone(request.getPhone());
        employee.setDob(request.getDob());
        employee.setGender(request.getGender());
        employee.setDesignation(request.getDesignation());
        if (image != null && !image.isEmpty())
            user.setImage(fileStorageService.store(image, "employee"));
        return EmployeeMapper.toResponse(employee);
    }

    @Transactional
    public void delete(Long id) {
        Employee employee = findById(id);
        userRepository.delete(employee.getUser());
        employeeRepository.delete(employee);
    }

    private Employee findById(Long id) {
        return employeeRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
    }

    private Address buildAddress(Long postOfficeId, String houseNo, String road) {
        PostOffice po = postOfficeRepository.findById(postOfficeId)
            .orElseThrow(() -> new BadRequestException("Post office not found"));
        Address addr = new Address();
        addr.setHouseNo(houseNo);
        addr.setRoad(road);
        addr.setPostOffice(po);
        return addr;
    }
}
